(() => {
  'use strict';

  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];
  const escapeHTML = value => String(value).replace(/[&<>'"]/g, character => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' })[character]);
  function formatRobux(value) {
    return Number(value || 0).toLocaleString();
  }
  function readWholeAmount(value) {
    const amount = Math.floor(Number(value));
    return Number.isFinite(amount) && amount > 0 ? amount : 0;
  }
  const appConfig = window.ROBOX_CONFIG || {};
  const realtimeApi = appConfig.realtimeApi || '';
  const publicWorldApi = realtimeApi ? `${realtimeApi}?resource=worlds` : '';
  const publicWorldOwnerToken = (() => {
    const key = 'robox-public-world-owner-token';
    let token = localStorage.getItem(key);
    if (!token) {
      token = `owner-${crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`}`;
      localStorage.setItem(key, token);
    }
    return token;
  })();
  const multiplayerPlayerId = (() => {
    const key = 'robox-multiplayer-player-id';
    let id = sessionStorage.getItem(key);
    if (!id) {
      id = `player-${crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`}`;
      sessionStorage.setItem(key, id);
    }
    return id;
  })();
  const multiplayer = { roomId:null, worldId:null, players:[], syncing:false, timer:null, connecting:false };

  async function roomApi(payload) {
    if (!realtimeApi) throw new Error('Room server is not configured.');
    const response = await fetch(realtimeApi, {
      method:'POST',
      headers:{ 'Content-Type':'application/json' },
      body:JSON.stringify(payload)
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'The public room could not be reached.');
    return result;
  }

  function multiplayerPayload(action, extra = {}) {
    return {
      action,
      roomId:multiplayer.roomId,
      worldId:multiplayer.worldId,
      playerId:multiplayerPlayerId,
      username:profile?.name || 'Player',
      x:game?.player?.x ?? 5,
      y:game?.player?.y ?? 5,
      z:game?.player?.z ?? 0,
      angle:game?.player?.angle ?? 0,
      appearance:{
        skin:profile?.skin, shirt:profile?.shirt, pants:profile?.pants,
        accent:profile?.accent, hairColor:profile?.hairColor,
        outfit:profile?.outfit, hair:profile?.hair
      },
      ...extra
    };
  }

  async function enterPublicRoom(worldId, action = 'join', roomId = '') {
    if (multiplayer.connecting) return;
    const world = readPublishedGames().find(item => item.id === worldId);
    if (!world) { showToast('World unavailable', 'Publish the world before creating a room'); return; }
    multiplayer.connecting = true;
    showToast(action === 'create' ? 'Creating room…' : 'Joining public room…', world.name);
    try {
      const result = await roomApi(multiplayerPayload(action, {
        roomId,
        worldId:world.id,
        worldName:world.name
      }));
      multiplayer.roomId = result.roomId;
      multiplayer.worldId = world.id;
      multiplayer.players = (result.players || []).filter(player => player.playerId !== multiplayerPlayerId);
      launchGame(world.id, true);
      $('#serverName').textContent = `Public room ${multiplayer.roomId} · ${(result.players || []).length}/12 players`;
      showToast(`Room ${multiplayer.roomId}`, action === 'create' ? 'Public room created' : 'Joined with live players');
      startRoomSync();
      refreshPublicRoomCards();
    } catch (error) {
      showToast('Could not join room', error.message || 'Try again in a moment');
    } finally {
      multiplayer.connecting = false;
    }
  }

  async function syncPublicRoom() {
    if (!game.active || !multiplayer.roomId || multiplayer.syncing) return;
    multiplayer.syncing = true;
    try {
      const result = await roomApi(multiplayerPayload('sync'));
      multiplayer.players = (result.players || []).filter(player => player.playerId !== multiplayerPlayerId);
      $('#serverName').textContent = `Public room ${multiplayer.roomId} · ${(result.players || []).length}/12 players`;
    } catch (_) {
      $('#serverName').textContent = `Room ${multiplayer.roomId} · reconnecting…`;
    } finally {
      multiplayer.syncing = false;
      if (game.active && multiplayer.roomId) multiplayer.timer = setTimeout(syncPublicRoom, 500);
    }
  }

  function startRoomSync() {
    clearTimeout(multiplayer.timer);
    multiplayer.timer = setTimeout(syncPublicRoom, 250);
  }

  function leavePublicRoom() {
    clearTimeout(multiplayer.timer);
    if (multiplayer.roomId && realtimeApi) {
      fetch(realtimeApi, {
        method:'POST', headers:{ 'Content-Type':'application/json' }, keepalive:true,
        body:JSON.stringify(multiplayerPayload('leave'))
      }).catch(() => {});
    }
    multiplayer.roomId = null;
    multiplayer.worldId = null;
    multiplayer.players = [];
    multiplayer.syncing = false;
  }

  async function refreshPublicRoomCards() {
    if (!realtimeApi) return;
    const lists = $$('[data-public-rooms-for]');
    await Promise.all(lists.map(async list => {
      const worldId = list.dataset.publicRoomsFor;
      try {
        const response = await fetch(`${realtimeApi}?worldId=${encodeURIComponent(worldId)}`, { cache:'no-store' });
        const result = await response.json();
        const rooms = Array.isArray(result.rooms) ? result.rooms : [];
        list.replaceChildren();
        if (!rooms.length) {
          const empty = document.createElement('span');
          empty.textContent = 'No rooms yet';
          list.append(empty);
          return;
        }
        rooms.forEach(room => {
          const button = document.createElement('button');
          button.type = 'button';
          button.dataset.joinRoom = room.id;
          button.dataset.roomWorld = worldId;
          button.textContent = `${room.id} · ${room.playerCount}/12`;
          button.title = `Join ${room.hostName}'s room`;
          list.append(button);
        });
      } catch (_) {
        list.textContent = 'Rooms reconnecting…';
      }
    }));
  }

  let syncingPublicWorlds = false;
  async function publishWorldToServer(world) {
    if (!publicWorldApi || !world) return;
    const response = await fetch(publicWorldApi, {
      method:'POST', headers:{ 'Content-Type':'application/json' },
      body:JSON.stringify({ action:'publish', ownerToken:publicWorldOwnerToken, worldId:world.id, world })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'Published world could not be shared.');
    return result.world;
  }

  async function deleteWorldFromServer(worldId) {
    if (!publicWorldApi) return;
    await fetch(publicWorldApi, {
      method:'POST', headers:{ 'Content-Type':'application/json' },
      body:JSON.stringify({ action:'delete', ownerToken:publicWorldOwnerToken, worldId })
    });
  }

  async function syncPublicWorldsFromServer() {
    if (!publicWorldApi || syncingPublicWorlds) return;
    syncingPublicWorlds = true;
    try {
      let response = await fetch(publicWorldApi, { cache:'no-store' });
      let result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Published worlds are unavailable.');
      let remoteGames = Array.isArray(result.games) ? result.games : [];
      const remoteIds = new Set(remoteGames.map(world => world.id));
      const ownedLocalGames = sessionMode === 'account'
        ? readPublishedGames().filter(world => String(world.owner || '').toLowerCase() === profile.name.toLowerCase())
        : [];
      const missingOwnedGames = ownedLocalGames.filter(world => !remoteIds.has(world.id));
      if (missingOwnedGames.length) {
        await Promise.all(missingOwnedGames.map(world => publishWorldToServer(world).catch(() => null)));
        response = await fetch(publicWorldApi, { cache:'no-store' });
        result = await response.json();
        if (response.ok) remoteGames = Array.isArray(result.games) ? result.games : remoteGames;
      }
      writePublishedGames(remoteGames);
      renderPublishedGames();
    } catch (_) {
      /* Keep the last downloaded public-world list while reconnecting. */
    } finally {
      syncingPublicWorlds = false;
    }
  }

  window.addEventListener('beforeunload', leavePublicRoom);
  (() => {
    const expectedVersion = Number(appConfig.version) || 0;
    if (!expectedVersion) return;
    try {
      const currentUrl = new URL(window.location.href);
      const sharedVersion = Number(currentUrl.searchParams.get('version')) || 0;
      if (sharedVersion >= expectedVersion) return;
      currentUrl.searchParams.set('version', String(expectedVersion));
      window.history.replaceState(null, '', currentUrl.href);
    } catch (_) { /* Keeping the visible share link fresh is optional. */ }
  })();
  let incomingSkinPayload = (() => {
    if (!window.location.hash.startsWith('#skin=')) return null;
    try {
      const encoded = window.location.hash.slice(6).replace(/-/g, '+').replace(/_/g, '/');
      const padded = encoded + '='.repeat((4 - encoded.length % 4) % 4);
      const bytes = Uint8Array.from(atob(padded), character => character.charCodeAt(0));
      return JSON.parse(new TextDecoder().decode(bytes));
    } catch (_) { return null; }
  })();
  const pageParams = new URLSearchParams(window.location.search);
  const requestedProOneBankingWallet = pageParams.get('bankWallet');
  const maintenancePreview = pageParams.get('maintenance') === '1';
  if (appConfig.maintenance || maintenancePreview) {
    $('#maintenanceMessage').textContent = appConfig.maintenanceMessage || "Robox is temporarily unavailable while we're making an update. Please check back soon.";
    $('#maintenanceScreen').classList.add('show');
  }
  const worldThemes = {
    grass: { label:'Grasslands', icon:'🌿', sky:['#69c8f2','#d7f3ee'], ground:'#62a84d', side:'#386f31', accent:'#ffd052' },
    desert: { label:'Desert', icon:'☀', sky:['#ed8a60','#ffd39b'], ground:'#d59b4b', side:'#9c632f', accent:'#52dce5' },
    moon: { label:'Moon', icon:'☾', sky:['#111a3a','#4a4774'], ground:'#7b8394', side:'#4a5061', accent:'#e1b94c' },
    neon: { label:'Neon', icon:'◇', sky:['#27104d','#a5269c'], ground:'#343b57', side:'#171c32', accent:'#54edff' }
  };
  const petCatalog = [
    { id:'cube-pup', name:'Cube Pup', type:'pup', icon:'🐶', price:50, color:'#d99a55', accent:'#7a4928', description:'A loyal blocky pup who loves every world.' },
    { id:'neon-kitty', name:'Neon Kitty', type:'cat', icon:'🐱', price:100, color:'#a95cff', accent:'#54edff', description:'A glowing cat with a bright cyan tail.' },
    { id:'moon-bot', name:'Moon Bot', type:'bot', icon:'🤖', price:150, color:'#8e9aaa', accent:'#f0cf62', description:'A tiny robot built for lunar adventures.' },
    { id:'tiny-dragon', name:'Tiny Dragon', type:'dragon', icon:'🐉', price:250, color:'#31bd83', accent:'#ff7e91', description:'A rare little dragon with colorful wings.' }
  ];
  const robuxBundles = [
    { amount:250, name:'Starter Stack', note:'Enough for a pet or a boost toward your designer pet.' },
    { amount:1000, name:'Designer Pack', note:'Perfect for making one custom pet right away.' },
    { amount:5000, name:'Mega Builder Vault', note:'Stock up for pets, designs, and future Robox items.' }
  ];
  const shopItemTypeIcons = { sword:'⚔️', hat:'🎩', trail:'✨', trophy:'🏆' };
  const kidtopiaRobuxRate = 10;
  const robuxPromoCodes = {
    '2017': { code:'2017', name:'2017 Throwback', discount:1, description:'100% off Robux Store purchases' }
  };
  const defaultKidtopiaMoney = 5000;
  const proOneBankingStorageKey = 'pro-one-banking-wallets-v1';
  const playerShopStorageKey = 'robox-player-shop-items-v1';
  const machineShopCatalog = [
    { id:'speed-burst', name:'Speed Burst', price:75, kind:'boost', effect:'speed', duration:90, description:'Move faster in this world for 90 seconds.' },
    { id:'jump-boots', name:'Jump Boots', price:120, kind:'boost', effect:'jump', duration:90, description:'Jump higher in this world for 90 seconds.' },
    { id:'coin-magnet', name:'Coin Magnet', price:150, kind:'boost', effect:'magnet', duration:90, description:'Pull nearby Robux coins to you for 90 seconds.' },
    { id:'builder-spark', name:'Builder Spark', price:200, kind:'item', description:'A saved machine item for your Robox profile.' }
  ];

  const defaultProfile = (name = 'Guest_Player') => ({
    name, coins: 100, kidtopiaMoney: defaultKidtopiaMoney, xp: 0, level: 1,
    skin: '#f5b640', shirt: '#7557ff', accent: '#55e6ff', pants: '#28325e', hairColor: '#2b1b18', hair: 'spikes', outfit: 'classic', face: 'smile',
    customSkins: [], equippedSkin: null,
    dailyClaimed: false, streak: 1, friends: [], worlds: [], deletedWorldIds: [], pets: [], customPets: [], equippedPet: null, machineItems: [], ownedShopItems: [], activeRobuxPromoCode: null, proOneBankingConnected: false, proOneBankingId: null, ageVerified: false, ageGroup: null
  });
  const readSavedAccount = () => {
    try { return JSON.parse(localStorage.getItem('robox-account') || 'null'); }
    catch (_) { return null; }
  };
  const readAccounts = () => {
    let accounts = {};
    try {
      const stored = JSON.parse(localStorage.getItem('robox-accounts') || '{}');
      if (stored && typeof stored === 'object' && !Array.isArray(stored)) accounts = stored;
    } catch (_) { accounts = {}; }
    const current = readSavedAccount();
    if (current?.username && current.profile) {
      const key = current.username.toLowerCase();
      accounts[key] = current;
      localStorage.setItem('robox-accounts', JSON.stringify(accounts));
    }
    return accounts;
  };
  const writeAccounts = accounts => localStorage.setItem('robox-accounts', JSON.stringify(accounts));
  const rememberAccount = account => {
    const accounts = readAccounts();
    accounts[account.username.toLowerCase()] = account;
    writeAccounts(accounts);
    localStorage.setItem('robox-account', JSON.stringify(account));
  };
  const savedAccountList = () => Object.values(readAccounts()).filter(account => account?.username && account.profile);
  const readPublishedGames = () => {
    try {
      const games = JSON.parse(localStorage.getItem('robox-published-games') || '[]');
      return Array.isArray(games) ? games : [];
    } catch (_) { return []; }
  };
  const writePublishedGames = games => localStorage.setItem('robox-published-games', JSON.stringify(games));
  const readWorldLibrary = () => {
    try {
      const library = JSON.parse(localStorage.getItem('robox-world-library') || '{}');
      return library && typeof library === 'object' ? library : {};
    } catch (_) { return {}; }
  };
  const writeWorldLibrary = library => localStorage.setItem('robox-world-library', JSON.stringify(library));
  const readPlayerShopItems = () => {
    try {
      const items = JSON.parse(localStorage.getItem(playerShopStorageKey) || '[]');
      return Array.isArray(items) ? items : [];
    } catch (_) { return []; }
  };
  const writePlayerShopItems = items => localStorage.setItem(playerShopStorageKey, JSON.stringify(Array.isArray(items) ? items : []));
  let profile = defaultProfile();
  let sessionMode = 'signed-out';
  let skinDraft = null;

  function readProOneBanking() {
    try {
      const saved = JSON.parse(localStorage.getItem(proOneBankingStorageKey) || '{}');
      return saved && typeof saved === 'object' ? { version:1, wallets:{}, ...saved, wallets: saved.wallets && typeof saved.wallets === 'object' ? saved.wallets : {} } : { version:1, wallets:{} };
    } catch (_) { return { version:1, wallets:{} }; }
  }
  function writeProOneBanking(bank) {
    localStorage.setItem(proOneBankingStorageKey, JSON.stringify({ version:1, wallets: bank.wallets || {}, updatedAt:new Date().toISOString() }));
  }
  function proOneBankingId() {
    const name = String(profile.name || 'Guest_Player').trim().toLowerCase().replace(/[^a-z0-9_]/g, '-') || 'guest-player';
    return `robox:${name}`;
  }
  function makeBankTransaction(change, note, balance) {
    return { id:`txn-${Date.now()}-${Math.random().toString(16).slice(2)}`, app:'Robox', change, note, balance, at:new Date().toISOString() };
  }
  function proOneBankingUrl() {
    const url = new URL(appConfig.proOneBankingUrl || 'https://mrawesomepro1.github.io/AWESOMECRAFT/pro-one-banking/');
    const id = profile.proOneBankingId || proOneBankingId();
    url.searchParams.set('wallet', id);
    url.searchParams.set('player', profile.name || 'Guest_Player');
    return url.href;
  }
  function syncProfileFromProOneBanking() {
    if (!profile.proOneBankingConnected || !profile.proOneBankingId) return false;
    const wallet = readProOneBanking().wallets?.[profile.proOneBankingId];
    if (!wallet || !Number.isFinite(Number(wallet.balance))) return false;
    profile.kidtopiaMoney = Number(wallet.balance);
    return true;
  }
  function syncProfileToProOneBanking(note = 'Robox balance synced') {
    if (!profile.proOneBankingConnected) return;
    const bank = readProOneBanking();
    const id = profile.proOneBankingId || proOneBankingId();
    const previous = bank.wallets[id];
    const nextBalance = Math.max(0, Math.floor(Number(profile.kidtopiaMoney) || 0));
    const previousBalance = Number(previous?.balance);
    const change = Number.isFinite(previousBalance) ? nextBalance - previousBalance : 0;
    bank.wallets[id] = {
      id,
      owner: profile.name || 'Guest_Player',
      currency: 'Kidtopia Money',
      connectedApps: [...new Set([...(previous?.connectedApps || []), 'Robox'])],
      balance: nextBalance,
      updatedAt: new Date().toISOString(),
      transactions: [
        ...(change || !previous ? [makeBankTransaction(change, note, nextBalance)] : []),
        ...(Array.isArray(previous?.transactions) ? previous.transactions : [])
      ].slice(0, 60)
    };
    profile.proOneBankingId = id;
    writeProOneBanking(bank);
  }
  function renderProOneBankingStatus() {
    const status = $('#proOneBankingStatus');
    if (!status) return;
    const connected = !!profile.proOneBankingConnected;
    const walletId = profile.proOneBankingId || proOneBankingId();
    const wallet = readProOneBanking().wallets?.[walletId];
    status.textContent = connected ? `Connected as ${profile.name}` : 'Not connected yet';
    $('#proOneBankingBalance').textContent = formatRobux(connected && wallet ? wallet.balance : profile.kidtopiaMoney);
    $('#connectProOneBanking').textContent = connected ? 'SYNC BANK' : 'CONNECT BANK';
    $('#proOneBankingLink').href = proOneBankingUrl();
  }
  function connectProOneBanking(openWebsite = false) {
    const id = profile.proOneBankingId || proOneBankingId();
    profile.proOneBankingConnected = true;
    profile.proOneBankingId = id;
    const existing = readProOneBanking().wallets?.[id];
    if (existing && Number.isFinite(Number(existing.balance))) profile.kidtopiaMoney = Number(existing.balance);
    saveProfile(existing ? 'Robox reconnected to Pro One Banking' : 'Robox connected to Pro One Banking');
    renderRobuxStore();
    showToast('Pro One Banking connected', 'Kidtopia Money now syncs to the website');
    if (openWebsite) window.open(proOneBankingUrl(), '_blank', 'noopener');
  }

  const saveProfile = (bankNote = 'Robox balance synced') => {
    if (profile.proOneBankingConnected) syncProfileToProOneBanking(bankNote);
    if (sessionMode === 'account') {
      rememberAccount({ username: profile.name, profile });
      const library = readWorldLibrary();
      library[profile.name.toLowerCase()] = {
        worlds: profile.worlds.map(world => ({ ...world })),
        deletedWorldIds: [...profile.deletedWorldIds],
        updatedAt: new Date().toISOString()
      };
      writeWorldLibrary(library);
    }
    updateProfileUI();
  };

  function updateProfileUI() {
    ['walletCoins', 'avatarCoins', 'petCoins', 'designerCoins', 'gameCoins', 'storeCoins'].forEach(id => { const el = document.getElementById(id); if (el) el.textContent = profile.coins; });
    ['kidtopiaMoney', 'storeKidtopiaMoney'].forEach(id => { const el = document.getElementById(id); if (el) el.textContent = Number(profile.kidtopiaMoney || 0).toLocaleString(); });
    $('#profileLevel').textContent = profile.level;
    $('#profileName').textContent = profile.name;
    $('#welcomeName').textContent = profile.name;
    document.documentElement.style.setProperty('--skin', profile.skin);
    document.documentElement.style.setProperty('--shirt', profile.shirt);
    document.documentElement.style.setProperty('--accent', profile.accent || '#55e6ff');
    document.documentElement.style.setProperty('--pants', profile.pants || '#28325e');
    document.documentElement.style.setProperty('--hair', profile.hairColor || '#2b1b18');
    $('#xpText').textContent = `${profile.xp} / 500`;
    const dailyButton = $('#claimDaily');
    dailyButton.textContent = profile.dailyClaimed ? '✓ Claimed today' : 'Claim +25 R';
    dailyButton.disabled = profile.dailyClaimed;
    const streak = Math.max(1, Math.min(7, profile.streak || 1));
    $('#streakText').textContent = `Day ${streak} of 7 — ${streak === 1 ? 'welcome!' : 'keep it going!'}`;
    $('.streak-dots').setAttribute('aria-label', `Day ${streak} of 7`);
    $$('.streak-dots i').forEach((dot, index) => dot.classList.toggle('earned', index < streak));
    const friendTotal = Array.isArray(profile.friends) ? profile.friends.length : 0;
    $('#friendCount').textContent = friendTotal;
    $('#friendCount').hidden = friendTotal === 0;
    $('#friendSummary').textContent = friendTotal === 0 ? 'You have no friends yet. Find some players and start a crew!' : `${friendTotal} friend${friendTotal === 1 ? '' : 's'} in your crew.`;
    const petTotal = Array.isArray(profile.pets) ? profile.pets.length : 0;
    $('#petCount').textContent = petTotal;
    $('#petCount').hidden = petTotal === 0;
    renderFriends();
    renderPets();
    renderShopItems();
    renderWorlds();
    renderPublishedGames();
  }

  setTimeout(() => $('#bootScreen').classList.add('done'), 1450);
  updateProfileUI();
  setTimeout(syncPublicWorldsFromServer, 250);
  setInterval(syncPublicWorldsFromServer, 15000);

  const accountScreen = $('#accountScreen');
  const authMessage = $('#authMessage');
  function showAuthMessage(message, success = false) {
    authMessage.textContent = message;
    authMessage.classList.toggle('success', success);
  }
  function verifyAge(birthdate, confirmed) {
    const born = birthdate ? new Date(`${birthdate}T12:00:00`) : null;
    const today = new Date();
    if (!born || Number.isNaN(born.getTime()) || born > today) return { error:'Enter a valid date of birth.' };
    let age = today.getFullYear() - born.getFullYear();
    if (today.getMonth() < born.getMonth() || (today.getMonth() === born.getMonth() && today.getDate() < born.getDate())) age--;
    if (age < 5 || age > 120) return { error:'This date of birth cannot be verified.' };
    if (!confirmed) return { error:'Please confirm that the date of birth is correct.' };
    return { ageGroup: age < 13 ? 'under-13' : '13-plus' };
  }
  function updateSignInAgeGate() {
    const typedUsername = $('#signInUsername')?.value.trim().toLowerCase();
    const saved = typedUsername ? readAccounts()[typedUsername] : readSavedAccount();
    const needsVerification = !!saved && !saved.profile?.ageVerified;
    $('#signInAgeVerification').classList.toggle('hidden', !needsVerification);
  }
  function updateSavedAccountHint() {
    const accounts = savedAccountList();
    const hint = $('#savedAccountHint');
    if (!accounts.length) { hint.textContent = 'No saved accounts on this device yet.'; return; }
    hint.textContent = accounts.length === 1 ? `Saved player found: ${accounts[0].username}` : `${accounts.length} saved accounts available. Enter a player name or use Switch Account.`;
  }
  function syncCustomizer() {
    $$('#skinSwatches button').forEach(button => button.classList.toggle('active', button.dataset.color === profile.skin));
    $$('#shirtSwatches button').forEach(button => button.classList.toggle('active', button.dataset.color === profile.shirt));
    $$('#hairStyles button').forEach(button => button.classList.toggle('active', button.dataset.hair === profile.hair));
    $('#studioAvatar .a-hair').className = `a-hair ${profile.hair}`;
    skinDraft = skinFromProfile();
    syncSkinLab();
  }
  function enterSession(nextProfile, mode) {
    profile = Object.assign(defaultProfile(nextProfile.name), nextProfile);
    let receivedSkin = null;
    if (!Array.isArray(profile.friends)) profile.friends = [];
    if (!Array.isArray(profile.worlds)) profile.worlds = [];
    if (!Array.isArray(profile.deletedWorldIds)) profile.deletedWorldIds = [];
    if (!Array.isArray(profile.pets)) profile.pets = [];
    if (!Array.isArray(profile.customPets)) profile.customPets = [];
    if (!Array.isArray(profile.customSkins)) profile.customSkins = [];
    if (!Array.isArray(profile.machineItems)) profile.machineItems = [];
    if (!Array.isArray(profile.ownedShopItems)) profile.ownedShopItems = [];
    if (!Number.isFinite(Number(profile.kidtopiaMoney))) profile.kidtopiaMoney = defaultKidtopiaMoney;
    if (requestedProOneBankingWallet) {
      profile.proOneBankingConnected = true;
      profile.proOneBankingId = requestedProOneBankingWallet;
    }
    if (profile.proOneBankingConnected) syncProfileFromProOneBanking();
    if (incomingSkinPayload) {
      receivedSkin = cleanSkin(incomingSkinPayload);
      const uploaded = { ...receivedSkin, id:`skin-${Date.now()}`, updatedAt:new Date().toISOString() };
      profile.customSkins = [uploaded, ...profile.customSkins.filter(item => String(item.name || '').toLowerCase() !== uploaded.name.toLowerCase())].slice(0,12);
      profile.equippedSkin = uploaded.id;
      applySkinToProfile(uploaded);
      incomingSkinPayload = null;
      try { history.replaceState(null, '', `${location.pathname}${location.search}`); } catch (_) { location.hash = ''; }
    }
    if (profile.equippedPet && !profile.pets.includes(profile.equippedPet)) profile.equippedPet = null;
    if (mode === 'account') {
      const backup = readWorldLibrary()[profile.name.toLowerCase()] || {};
      const backupWorlds = Array.isArray(backup.worlds) ? backup.worlds : [];
      const backupDeleted = Array.isArray(backup.deletedWorldIds) ? backup.deletedWorldIds : [];
      const publishedWorlds = readPublishedGames().filter(world => String(world.owner || '').toLowerCase() === profile.name.toLowerCase());
      const deletedIds = new Set([...backupDeleted, ...profile.deletedWorldIds]);
      profile.worlds.forEach(world => { if (world?.id) deletedIds.delete(world.id); });
      const recoveredWorlds = new Map();
      [...publishedWorlds, ...backupWorlds, ...profile.worlds].forEach(world => {
        if (world?.id && !deletedIds.has(world.id)) recoveredWorlds.set(world.id, { ...world });
      });
      profile.worlds = [...recoveredWorlds.values()];
      profile.deletedWorldIds = [...deletedIds];
    } else {
      profile.worlds = profile.worlds.filter(world => !profile.deletedWorldIds.includes(world.id));
    }
    sessionMode = mode;
    if (mode === 'account') saveProfile();
    accountScreen.classList.add('hidden');
    $('#appShell').removeAttribute('inert');
    showAuthMessage('');
    updateProfileUI(); syncCustomizer();
    if (receivedSkin) showToast('Skin uploaded!', `${receivedSkin.name} is now equipped`);
    beep(760, .12);
  }
  function selectAuthTab(mode) {
    $$('[data-auth-tab]').forEach(tab => { const active = tab.dataset.authTab === mode; tab.classList.toggle('active', active); tab.setAttribute('aria-selected', active); });
    $('#createAccountForm').classList.toggle('hidden', mode !== 'create');
    $('#signInForm').classList.toggle('hidden', mode !== 'signin');
    updateSignInAgeGate();
    showAuthMessage('');
  }
  $$('[data-auth-tab]').forEach(button => button.addEventListener('click', () => selectAuthTab(button.dataset.authTab)));
  $('#signInUsername').addEventListener('input', updateSignInAgeGate);
  $('#createAccountForm').addEventListener('submit', event => {
    event.preventDefault();
    const username = $('#createUsername').value.trim();
    if (readAccounts()[username.toLowerCase()]) { showAuthMessage('That account already exists on this device. Choose Sign in instead.'); return; }
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) { showAuthMessage('Use 3–16 letters, numbers, or underscores.'); return; }
    const ageCheck = verifyAge($('#createBirthdate').value, $('#confirmAge').checked);
    if (ageCheck.error) { showAuthMessage(ageCheck.error); return; }
    const next = defaultProfile(username);
    next.ageVerified = true;
    next.ageGroup = ageCheck.ageGroup;
    rememberAccount({ username, profile: next });
    enterSession(next, 'account');
  });
  $('#signInForm').addEventListener('submit', event => {
    event.preventDefault();
    const username = $('#signInUsername').value.trim();
    const saved = readAccounts()[username.toLowerCase()];
    if (!saved) { showAuthMessage('No saved account matches that player name.'); return; }
    if (!saved.profile?.ageVerified) {
      const ageCheck = verifyAge($('#signInBirthdate').value, $('#signInConfirmAge').checked);
      if (ageCheck.error) { showAuthMessage(ageCheck.error); return; }
      saved.profile.ageVerified = true;
      saved.profile.ageGroup = ageCheck.ageGroup;
    }
    rememberAccount(saved);
    enterSession(saved.profile, 'account');
  });
  $('#continueGuest').addEventListener('click', () => enterSession(defaultProfile(), 'guest'));
  const savedOnLoad = readSavedAccount();
  updateSavedAccountHint();
  if (savedOnLoad) { $('#signInUsername').value = savedOnLoad.username; selectAuthTab('signin'); }

  // Tiny synthesized UI sounds; no external audio assets required.
  let audioEnabled = true;
  let audioContext;
  function beep(frequency = 440, duration = .06, volume = .025) {
    if (!audioEnabled) return;
    try {
      audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = 'sine'; oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(volume, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(.0001, audioContext.currentTime + duration);
      oscillator.connect(gain).connect(audioContext.destination);
      oscillator.start(); oscillator.stop(audioContext.currentTime + duration);
    } catch (_) { /* Audio is optional. */ }
  }

  function switchView(name) {
    $$('.view').forEach(view => view.classList.toggle('active', view.id === `${name}View`));
    $$('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.view === name));
    window.scrollTo({ top: 0, behavior: 'smooth' });
    beep(520);
  }
  $$('[data-view]').forEach(button => button.addEventListener('click', () => switchView(button.dataset.view)));

  const updateNotes = [
    { version:'UPDATE 26 • LATEST', badge:'UPDATE 26', title:'Offline App', summary:'Robox now caches the app shell, core files, main image, world templates, and download package so it can reopen after the first online visit.', features:['New web app manifest for installing or saving Robox','Service worker caches the main game, styles, scripts, image, templates, and ZIP','Offline reload support after opening the public link once while online'] },
    { version:'UPDATE 25', badge:'UPDATE 25', title:'Platform Guide', summary:'Robox now has a Platform page for the game hub, creator tools, Robux economy, safety, genres, history notes, and future roadmap ideas.', features:['New Platform button on the sidebar and home screen','Core features, creator tools, popular genres, safety, and economy sections','Roadmap cards for engine, discovery, marketplace, audio, identity, and trust upgrades'] },
    { version:'UPDATE 24', badge:'UPDATE 24', title:'Mouse Look', summary:'3D Brainrot worlds now let you move the mouse to look around while you play.', features:['Click the 3D game to lock mouse look','Move the mouse to look left, right, up, and down','WASD movement follows the camera direction in 3D Brainrot worlds'] },
    { version:'UPDATE 23', badge:'UPDATE 23', title:'3D Brainrot Obby', summary:'Brainrot worlds now use a behind-the-player 3D obby camera, and platforms can grow without the old 32 × 32 stop.', features:['Brainrot base games look like forward-running 3D platform worlds','WASD moves like an obby: forward, back, left, and right','Expand keeps growing your creator platform with no fixed max size'] },
    { version:'UPDATE 22', badge:'UPDATE 22', title:'Brainrot Bases', summary:'Brainrot worlds now have a real base game: grab brainrots, carry them home, and score rewards.', features:['Brainrot worlds automatically turn on base-game mode','Glowing brainrots spawn in the world for players to collect','Bring a brainrot to YOUR BASE to store it and earn Robux'] },
    { version:'UPDATE 21', badge:'UPDATE 21', title:'World Files', summary:'You can now make a .roboxworld file and import it to create a draft world.', features:['Download a starter world-file template','Import .roboxworld or JSON files as saved draft worlds','Export any world you made as a reusable file'] },
    { version:'UPDATE 20', badge:'UPDATE 20', title:'Public World Rooms', summary:'Published worlds now have real shared rooms for players on different devices.', features:['Create a public room from a published world','Join the first open room or choose a visible room code','See up to 12 live players moving inside the same world'] },
    { version:'UPDATE 19', badge:'UPDATE 19', title:'Shop Item Maker', summary:'Players can now make custom things and put them inside the in-game shop.', features:['Create custom shop items from the Pets page','Choose item type, color, description, and Robux price','Created items appear in the in-game shop for players to buy'] },
    { version:'UPDATE 18', badge:'UPDATE 18', title:'iPad Shop Button', summary:'iPad and iPhone players now have a big touch button to open the in-game shop.', features:['New SHOP button beside BUILD and TALK on touch controls','The button opens the pet shop without needing a keyboard','Works when iPad/iPhone controls are selected'] },
    { version:'UPDATE 17', badge:'UPDATE 17', title:'Promo Codes', summary:'Robux Store now has promo codes, and code 2017 gives 100% off.', features:['New promo-code box inside the Robux Store','Code 2017 makes Robux purchases cost K 0','Bundle and custom prices update when the code is active'] },
    { version:'UPDATE 16', badge:'UPDATE 16', title:'Infinite Custom Amounts', summary:'Bank deposits now add the exact amount, and custom Robux has no cap.', features:['Pro One Banking deposits use the exact typed amount','Custom Robux amount no longer stops at 100,000','Pro One Banking opens Robox Update 16'] },
    { version:'UPDATE 15', badge:'UPDATE 15', title:'Pro One Banking', summary:'Connect Kidtopia Money to the Pro One Banking website.', features:['Robux Store has Connect Bank and Open Website buttons','Kidtopia Money syncs with the Pro One Banking website wallet','Robux purchases create banking transactions'] },
    { version:'UPDATE 14', badge:'UPDATE 14', title:'Robux Machines', summary:'Place Robux Machines in worlds and buy Robux with Kidtopia Money.', features:['Build mode has a Robux Machine tool','Machines open a shop for boosts and items','Type any Robux amount and pay with Kidtopia Money'] },
    { version:'UPDATE 13', badge:'UPDATE 13', title:'Renamed to Robox', summary:'The visible app name is now Robox everywhere.', features:['Boot screen and top bar now say Robox','Shared links use the latest version','Awesome Development listing now says Robox'] },
    { version:'UPDATE 12', badge:'UPDATE 12', title:'Multiplayer Setup Needed', summary:'Robox now shows the truth when real-player multiplayer is not connected yet.', features:['Sad-face multiplayer setup screen','Play Together buttons do not fake real players','Friends can still be saved, managed, and unfriended'] },
    { version:'UPDATE 11', badge:'UPDATE 11', title:'Robux Store', summary:'Buy in-game Robux bundles for your Robox account without using real money.', features:['New Buy Robux buttons around the app','R 250, R 1,000, and R 5,000 demo bundles','Balances update instantly and save to signed-in accounts'] },
    { version:'UPDATE 10', badge:'UPDATE 10', title:'Standalone Skin Maker', summary:'Create custom player skins in a separate app, then hand a finished look into Robox.', features:['Separate full-screen skin creator','Saved 12-skin library with one-click upload','Portable .roboxskin and PNG exports'] },
    { version:'UPDATE 9', badge:'UPDATE 9', title:'Pet Designer', summary:'Design a one-of-a-kind pet with your own name, style, and colors for R 1,000 Robux.', features:['Live custom-pet preview','Choose four styles and two colors','Create and equip for R 1,000'] },
    { version:'UPDATE 8', badge:'UPDATE 8', title:'Pets & Robux Shop', summary:'Unlock pets with in-game Robux and equip a companion that follows you into worlds.', features:['Four pets in the Pet Shop','Pay with saved in-game R currency','Press E in a world to open the shop'] },
    { version:'UPDATE 7', badge:'UPDATE 7', title:'Stay Current & Download', summary:'Robox can detect an older copy, reload every missing feature, and download an offline package.', features:['Automatic latest-version checks','One-tap Reload Latest recovery','Downloadable offline ZIP package'] },
    { version:'UPDATE 6', badge:'UPDATE 6', title:'Control Switcher', summary:'Choose how you play before entering a world or switch controls during a game.', features:['Controls button on the home screen','Switch controls while a game is paused','Save Auto, Keyboard & Mouse, or Touch mode'] },
    { version:'UPDATE 5', badge:'UPDATE 5', title:'Multiple Accounts', summary:'Save several player accounts on one device and switch without losing progress.', features:['Switch accounts from Settings','Keep each profile\'s worlds and friends separate','Migrate existing accounts automatically'] },
    { version:'UPDATE 4', badge:'UPDATE 4', title:'Invites & Permissions', summary:'World owners can invite players by username and decide who gets build access.', features:['Invite exact player usernames','Choose play-only or Can Build','Change permissions or remove invites'] },
    { version:'UPDATE 3', badge:'UPDATE 3', title:'Expandable Worlds', summary:'Creators can grow their platform and share a finished game with everyone.', features:['Expand platforms up to 32 × 32','Publish and update live games','Right-click to place and left-click to wreck'] },
    { version:'UPDATE 2', badge:'UPDATE 2', title:'World Creator', summary:'Every experience begins with a world made by a player.', features:['Create named worlds with four environments','Save block changes automatically','Delete drafts and their published copy'] },
    { version:'UPDATE 1', badge:'UPDATE 1', title:'Accounts & Friends', summary:'Player profiles start clean and stay saved on the device.', features:['Age verification for accounts','Add and unfriend by username','Start daily rewards at Day 1'] }
  ];
  function rebuildUpdatesList() {
    const list = $('#updatesList');
    if (!list) return;
    list.innerHTML = updateNotes.map((note, index) => {
      const badge = index === 0 ? 'NEW' : note.badge.replace('UPDATE ', '');
      const summary = note.summary;
      return `<button class="${index === 0 ? 'active' : ''}" data-update-index="${index}"><span>${escapeHTML(badge)}</span><b>${escapeHTML(note.title)}</b><small>${escapeHTML(summary)}</small></button>`;
    }).join('');
  }
  rebuildUpdatesList();
  let activeUpdateIndex = 0;
  function renderUpdate(index) {
    activeUpdateIndex = Math.max(0, Math.min(updateNotes.length - 1, index));
    const note = updateNotes[activeUpdateIndex];
    $('#updateVersion').textContent = note.badge;
    $('#updateKicker').textContent = note.version;
    $('#updateTitle').textContent = note.title;
    $('#updateSummary').textContent = note.summary;
    $('#updateFeatures').innerHTML = note.features.map(feature => `<li>${escapeHTML(feature)}</li>`).join('');
    $('#updatePosition').textContent = `${activeUpdateIndex + 1} / ${updateNotes.length}`;
    $('#previousUpdate').disabled = activeUpdateIndex === 0;
    $('#nextUpdate').disabled = activeUpdateIndex === updateNotes.length - 1;
    $$('#updatesList [data-update-index]').forEach(button => button.classList.toggle('active', Number(button.dataset.updateIndex) === activeUpdateIndex));
  }
  $('#updatesList').addEventListener('click', event => {
    const button = event.target.closest('[data-update-index]');
    if (button) renderUpdate(Number(button.dataset.updateIndex));
  });
  $('#previousUpdate').addEventListener('click', () => renderUpdate(activeUpdateIndex - 1));
  $('#nextUpdate').addEventListener('click', () => renderUpdate(activeUpdateIndex + 1));
  renderUpdate(0);

  function registerOfflineApp() {
    if (!('serviceWorker' in navigator) || location.protocol === 'file:') return;
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').then(() => {
        navigator.storage?.persist?.().catch(() => {});
        const flag = 'robox-offline-ready-v26';
        if (!localStorage.getItem(flag)) {
          localStorage.setItem(flag, 'yes');
          showToast('Offline ready', 'Robox can reopen after this first online visit');
        }
      }).catch(() => {});
    });
    window.addEventListener('offline', () => showToast('Offline mode', 'Using saved Robox files'));
  }
  registerOfflineApp();

  const currentAppVersion = Number(appConfig.version) || 0;
  const canonicalAppUrl = appConfig.canonicalUrl || 'https://mrawesomepro1.github.io/AWESOMECRAFT/robox-2-0/';
  let latestAppVersion = currentAppVersion;
  async function checkForUpdates(manual = false) {
    try {
      const response = await fetch(`${canonicalAppUrl}version.json?check=${Date.now()}`, { cache:'no-store' });
      if (!response.ok) throw new Error('Update server unavailable');
      const latest = await response.json();
      latestAppVersion = Number(latest.version) || currentAppVersion;
      const needsUpdate = latestAppVersion > currentAppVersion;
      $('#updateBanner').classList.toggle('show', needsUpdate);
      if (manual) showToast(needsUpdate ? 'New update found!' : 'Robox is up to date', needsUpdate ? `Update ${latestAppVersion} is ready to reload` : `You have Update ${currentAppVersion}`);
      return needsUpdate;
    } catch (_) {
      if (manual) showToast('Could not check updates', 'Check your internet connection and try again');
      return false;
    }
  }
  function reloadLatestVersion() {
    const target = new URL(canonicalAppUrl);
    target.searchParams.set('version', String(latestAppVersion || currentAppVersion));
    target.searchParams.set('reload', String(Date.now()));
    window.location.replace(target.href);
  }
  $('#checkUpdatesButton').addEventListener('click', () => checkForUpdates(true));
  $('#reloadLatestButton').addEventListener('click', reloadLatestVersion);
  setTimeout(() => checkForUpdates(false), 1800);

  const robuxCost = amount => Math.max(1, Math.ceil((Number(amount) || 0) / kidtopiaRobuxRate));
  const normalizePromoCode = value => String(value || '').trim().toUpperCase();
  function activeRobuxPromo() {
    return robuxPromoCodes[normalizePromoCode(profile.activeRobuxPromoCode)] || null;
  }
  function robuxCostWithPromo(amount) {
    const baseCost = robuxCost(amount);
    const promo = activeRobuxPromo();
    if (!promo) return { baseCost, finalCost:baseCost, saved:0, promo:null };
    const discount = Math.max(0, Math.min(1, Number(promo.discount) || 0));
    const finalCost = Math.max(0, Math.ceil(baseCost * (1 - discount)));
    return { baseCost, finalCost, saved:baseCost - finalCost, promo };
  }
  function robuxCostLabel(amount) {
    const deal = robuxCostWithPromo(amount);
    if (!deal.promo) return `COSTS K ${formatRobux(deal.baseCost)}`;
    if (deal.finalCost === 0) return `FREE WITH CODE ${deal.promo.code}`;
    return `CODE ${deal.promo.code}: K ${formatRobux(deal.finalCost)} (WAS K ${formatRobux(deal.baseCost)})`;
  }
  function makeRobuxButton(id, className, label, detail = '') {
    const button = document.createElement('button');
    button.type = 'button';
    button.id = id;
    button.className = className;
    button.dataset.openRobuxStore = 'true';
    button.innerHTML = detail ? `<span>R+</span><div><b>${label}</b><small>${detail}</small></div>` : `<span>R+</span><b>${label}</b>`;
    return button;
  }
  function injectRobuxStoreUI() {
    const download = $('#downloadGameButton');
    if (download) download.href = appConfig.downloadFile || 'robox-update-26-download.zip';
    const walletPill = $('#walletCoins')?.closest('.coin-pill');
    if (walletPill && !$('#topRobuxButton')) walletPill.insertAdjacentElement('afterend', makeRobuxButton('topRobuxButton', 'robux-store-button top-robux-button', 'BUY'));
    if ($('#downloadGameButton') && !$('#homeRobuxButton')) $('#downloadGameButton').insertAdjacentElement('beforebegin', makeRobuxButton('homeRobuxButton', 'home-robux-button', 'BUY ROBUX'));
    const petActions = $('.pet-page-actions');
    if (petActions && !$('#petRobuxButton')) {
      const petCoins = $('#petCoins')?.closest('.coin-pill');
      const button = makeRobuxButton('petRobuxButton', 'mini-robux-button', 'BUY ROBUX');
      if (petCoins) petCoins.insertAdjacentElement('beforebegin', button); else petActions.appendChild(button);
    }
    const designerBalance = $('.designer-balance');
    if (designerBalance && !$('#designerRobuxButton')) designerBalance.insertAdjacentElement('afterend', makeRobuxButton('designerRobuxButton', 'designer-buy-robux', 'GET MORE ROBUX'));
    const gameShopCoins = $('#gamePetCoins')?.closest('.coin-pill');
    if (gameShopCoins && !$('#gameRobuxButton')) gameShopCoins.insertAdjacentElement('beforebegin', makeRobuxButton('gameRobuxButton', 'mini-robux-button game-robux-button', 'BUY ROBUX'));
    if (!$('#robuxStoreModal')) {
      document.body.insertAdjacentHTML('beforeend', `<div class="modal robux-store-modal" id="robuxStoreModal" role="dialog" aria-modal="true" aria-labelledby="robuxStoreTitle"><div class="modal-card robux-store-card"><button class="modal-close" id="closeRobuxStore" aria-label="Close Robux store">×</button><div class="robux-store-hero"><div><p class="eyebrow">KIDTOPIA EXCHANGE</p><h2 id="robuxStoreTitle">Buy Robux</h2><p>Use Kidtopia Money to buy pretend Robux for this Robox profile.</p></div><div class="robux-wallet-stack"><div class="robux-balance-card"><span>YOUR ROBUX</span><strong><i class="coin">R</i> <b id="storeCoins">100</b></strong></div><div class="kidtopia-balance-card"><span>KIDTOPIA MONEY</span><strong>K <b id="storeKidtopiaMoney">5,000</b></strong></div></div></div><div class="robux-bundle-grid" id="robuxBundleGrid"></div><form class="custom-robux-form" id="customRobuxForm"><label for="customRobuxAmount"><span>CUSTOM ROBUX AMOUNT</span><input id="customRobuxAmount" type="number" inputmode="numeric" min="1" step="1" value="100" placeholder="Infinite custom amount"></label><button type="submit">BUY CUSTOM</button><small id="customRobuxCost">No max — costs K 10 Kidtopia Money</small></form><form class="promo-code-form" id="robuxPromoForm"><label for="robuxPromoCode"><span>PROMO CODE</span><input id="robuxPromoCode" autocomplete="off" inputmode="text" maxlength="20" placeholder="Try 2017"></label><button type="submit">APPLY</button><small id="robuxPromoStatus">Enter code 2017 for 100% off.</small></form><p class="robux-safe-note"><b>Robox-only store:</b> these are pretend in-game purchases. No real money, payment cards, or Roblox account is used. Kidtopia Money is pretend game money too.</p><p class="robux-store-message" id="robuxStoreMessage" aria-live="polite"></p></div></div>`);
    }
    const storeCard = $('#robuxStoreModal .robux-store-card');
    if (storeCard && !$('#proOneBankingCard')) {
      storeCard.insertAdjacentHTML('beforeend', `<div class="pro-one-banking-card" id="proOneBankingCard"><div><p class="eyebrow">PRO ONE BANKING WEBSITE</p><h3>Connect Kidtopia Money</h3><p>Your Kidtopia Money can sync with the Pro One Banking website on this public site.</p><small id="proOneBankingStatus">Not connected yet</small></div><div class="pro-one-bank-balance"><span>BANK BALANCE</span><strong>K <b id="proOneBankingBalance">5,000</b></strong></div><div class="pro-one-bank-actions"><button type="button" id="connectProOneBanking">CONNECT BANK</button><button type="button" id="openProOneBanking">OPEN WEBSITE</button><a id="proOneBankingLink" href="https://mrawesomepro1.github.io/AWESOMECRAFT/pro-one-banking/" target="_blank" rel="noopener">PUBLIC BANK LINK</a></div></div>`);
    }
  }
  function renderRobuxStore() {
    const grid = $('#robuxBundleGrid');
    if (!grid) return;
    grid.innerHTML = robuxBundles.map((bundle, index) => `<button class="robux-bundle ${index === 1 ? 'featured' : ''}" type="button" data-robux-amount="${bundle.amount}"><span class="coin">R</span><strong>${formatRobux(bundle.amount)}</strong><b>${escapeHTML(bundle.name)}</b><small>${escapeHTML(bundle.note)}</small><em>${escapeHTML(robuxCostLabel(bundle.amount))}</em></button>`).join('');
    const storeCoins = $('#storeCoins');
    if (storeCoins) storeCoins.textContent = profile.coins;
    const kidtopiaMoney = $('#storeKidtopiaMoney');
    if (kidtopiaMoney) kidtopiaMoney.textContent = formatRobux(profile.kidtopiaMoney);
    updateCustomRobuxCost();
    renderRobuxPromoCode();
    renderProOneBankingStatus();
  }
  function updateCustomRobuxCost() {
    const amountInput = $('#customRobuxAmount');
    const costOutput = $('#customRobuxCost');
    if (!amountInput || !costOutput) return;
    const amount = readWholeAmount(amountInput.value) || 1;
    const deal = robuxCostWithPromo(amount);
    costOutput.textContent = deal.promo && deal.finalCost === 0 ? `No max - free with code ${deal.promo.code}.` : `No max - costs K ${formatRobux(deal.finalCost)} Kidtopia Money`;
  }
  function renderRobuxPromoCode() {
    const input = $('#robuxPromoCode');
    const status = $('#robuxPromoStatus');
    if (!input || !status) return;
    const promo = activeRobuxPromo();
    if (promo && document.activeElement !== input) input.value = promo.code;
    status.textContent = promo ? `Code ${promo.code} active: 100% off.` : 'Enter code 2017 for 100% off.';
    status.classList.toggle('active', !!promo);
  }
  function applyRobuxPromoCode(value) {
    const code = normalizePromoCode(value);
    const promo = robuxPromoCodes[code];
    if (!promo) {
      $('#robuxPromoStatus').textContent = 'That promo code is not available. Try 2017.';
      showToast('Promo not found', 'Try code 2017');
      beep(240, .12);
      return;
    }
    profile.activeRobuxPromoCode = promo.code;
    saveProfile(`Promo code ${promo.code} applied`);
    renderRobuxStore();
    $('#robuxStoreMessage').textContent = `Promo code ${promo.code} applied: 100% off Robux purchases.`;
    showToast('Promo code applied!', `${promo.code} gives 100% off`);
    beep(920, .14);
  }
  function buyRobuxWithKidtopia(amount) {
    amount = readWholeAmount(amount);
    if (!amount) {
      $('#robuxStoreMessage').textContent = 'Enter a custom Robux amount of 1 or more.';
      return;
    }
    const deal = robuxCostWithPromo(amount);
    const cost = deal.finalCost;
    if (profile.kidtopiaMoney < cost) {
      $('#robuxStoreMessage').textContent = `You need K ${formatRobux(cost - profile.kidtopiaMoney)} more Kidtopia Money.`;
      showToast('Not enough Kidtopia Money', `Need K ${formatRobux(cost)}`);
      beep(240, .12);
      return;
    }
    profile.kidtopiaMoney -= cost;
    profile.coins += amount;
    const purchaseNote = cost ? `Bought R ${formatRobux(amount)} Robux with Kidtopia Money` : `Promo code ${deal.promo?.code || 'FREE'} redeemed for R ${formatRobux(amount)} Robux`;
    saveProfile(purchaseNote);
    renderRobuxStore();
    const saveNote = sessionMode === 'account' ? 'Saved to your account.' : 'Guest Robux may reset when the guest session ends.';
    const paidText = cost ? `with K ${formatRobux(cost)} Kidtopia Money` : `free with code ${deal.promo?.code || 'PROMO'}`;
    $('#robuxStoreMessage').textContent = `Bought R ${formatRobux(amount)} ${paidText}. ${saveNote}`;
    showToast('Robux bought!', cost ? `+R ${formatRobux(amount)} - K ${formatRobux(cost)}` : `+R ${formatRobux(amount)} - 100% off`);
    beep(1040, .18);
  }
  function openRobuxStore() {
    renderRobuxStore();
    $('#robuxStoreMessage').textContent = '';
    $('#robuxStoreModal').classList.add('show');
    beep(720, .08);
  }
  function closeRobuxStore() {
    $('#robuxStoreModal').classList.remove('show');
  }
  injectRobuxStoreUI();
  document.addEventListener('click', event => {
    if (event.target.closest('[data-open-robux-store]')) openRobuxStore();
  });
  $('#closeRobuxStore').addEventListener('click', closeRobuxStore);
  $('#robuxStoreModal').addEventListener('click', event => { if (event.target === $('#robuxStoreModal')) closeRobuxStore(); });
  $('#robuxBundleGrid').addEventListener('click', event => {
    const button = event.target.closest('[data-robux-amount]');
    if (!button) return;
    buyRobuxWithKidtopia(button.dataset.robuxAmount);
  });
  $('#customRobuxAmount').addEventListener('input', updateCustomRobuxCost);
  $('#customRobuxForm').addEventListener('submit', event => {
    event.preventDefault();
    buyRobuxWithKidtopia($('#customRobuxAmount').value);
  });
  $('#robuxPromoForm').addEventListener('submit', event => {
    event.preventDefault();
    applyRobuxPromoCode($('#robuxPromoCode').value);
  });
  $('#connectProOneBanking').addEventListener('click', () => connectProOneBanking(false));
  $('#openProOneBanking').addEventListener('click', () => connectProOneBanking(true));
  window.addEventListener('storage', event => {
    if (event.key !== proOneBankingStorageKey || !profile.proOneBankingConnected) return;
    if (syncProfileFromProOneBanking()) {
      if (sessionMode === 'account') rememberAccount({ username: profile.name, profile });
      updateProfileUI();
      renderRobuxStore();
      showToast('Bank balance synced', 'Pro One Banking updated Kidtopia Money');
    }
  });

  $('#soundToggle').addEventListener('click', event => {
    audioEnabled = !audioEnabled;
    event.currentTarget.classList.toggle('muted', !audioEnabled);
    event.currentTarget.querySelector('span').textContent = audioEnabled ? '♪' : '×';
    beep(640);
  });

  const controlsModal = $('#controlsModal');
  const validControlModes = ['auto','keyboard','touch'];
  const detectedStartControlMode = window.matchMedia && window.matchMedia('(pointer: coarse)').matches ? 'touch' : 'keyboard';
  let controlMode = localStorage.getItem('robox-control-mode') || detectedStartControlMode;
  let resumeAfterControls = false;
  if (!validControlModes.includes(controlMode)) controlMode = 'auto';
  function controlModeLabel(mode) {
    return mode === 'keyboard' ? 'Keyboard & Mouse' : mode === 'touch' ? 'Touch Controls' : 'Automatic';
  }
  function syncStartDeviceChoice(mode) {
    const choice = $('#startDeviceChoice');
    if (!choice) return;
    const startMode = mode === 'keyboard' ? 'keyboard' : mode === 'touch' ? 'touch' : detectedStartControlMode;
    $$('[data-start-device]', choice).forEach(button => button.classList.toggle('active', button.dataset.startDevice === startMode));
    const message = $('#startDeviceMessage');
    if (message) message.textContent = startMode === 'keyboard' ? 'Computer controls selected: keyboard, mouse, and E for shop.' : 'iPad/iPhone controls selected: big touch buttons for play.';
  }
  function applyControlMode(mode, announce = true) {
    controlMode = validControlModes.includes(mode) ? mode : 'auto';
    localStorage.setItem('robox-control-mode', controlMode);
    document.body.classList.toggle('force-keyboard', controlMode === 'keyboard');
    document.body.classList.toggle('force-touch', controlMode === 'touch');
    document.body.dataset.controlMode = controlMode;
    $$('#controlModeList [data-control-mode]').forEach(button => button.classList.toggle('active', button.dataset.controlMode === controlMode));
    syncStartDeviceChoice(controlMode);
    $('#controlCurrent').textContent = `${controlModeLabel(controlMode)} selected`;
    if (announce) {
      beep(760, .1);
      if (game.active) showToast('Controls changed', controlModeLabel(controlMode));
    }
  }
  function openControlsModal() {
    resumeAfterControls = !!game.active && !game.paused;
    if (resumeAfterControls) togglePause(true);
    controlsModal.classList.add('show');
  }
  function closeControlsModal() {
    controlsModal.classList.remove('show');
    if (resumeAfterControls && game.active) togglePause(false);
    resumeAfterControls = false;
  }
  $('#homeControlsButton').addEventListener('click', openControlsModal);
  $('#gameControlsButton').addEventListener('click', openControlsModal);
  $$('[data-close-controls]').forEach(button => button.addEventListener('click', closeControlsModal));
  controlsModal.addEventListener('click', event => { if (event.target === controlsModal) closeControlsModal(); });
  $('#controlModeList').addEventListener('click', event => {
    const button = event.target.closest('[data-control-mode]');
    if (button) applyControlMode(button.dataset.controlMode);
  });
  $('#startDeviceChoice')?.addEventListener('click', event => {
    const button = event.target.closest('[data-start-device]');
    if (button) applyControlMode(button.dataset.startDevice);
  });
  applyControlMode(controlMode, false);

  $('#claimDaily').addEventListener('click', event => {
    if (profile.dailyClaimed) return;
    profile.coins += 25; profile.dailyClaimed = true; saveProfile(); beep(880, .13);
    event.currentTarget.textContent = '✓ Claimed today'; event.currentTarget.disabled = true;
  });
  const search = $('#searchInput');
  search.addEventListener('input', () => {
    const query = search.value.trim().toLowerCase();
    const cards = $$('.game-card');
    if (!cards.length) { $('#emptySearch').classList.remove('show'); return; }
    let visible = 0;
    cards.forEach(card => { const show = card.dataset.title.includes(query); card.hidden = !show; visible += show; });
    $('#emptySearch').classList.toggle('show', visible === 0);
  });
  window.addEventListener('keydown', event => {
    if (event.key === '/' && !game.active && document.activeElement !== search) { event.preventDefault(); search.focus(); }
    if (event.key === 'Escape' && document.activeElement === search) search.blur();
  });
  $('#seeAllBtn')?.addEventListener('click', () => { search.value = ''; search.focus(); search.dispatchEvent(new Event('input')); });

  const skinKeys = ['skin', 'shirt', 'accent', 'pants', 'hairColor'];
  const skinPalettes = {
    neon: { shirt:'#7557ff', accent:'#55e6ff', pants:'#202858', hairColor:'#241b4d' },
    sunset: { shirt:'#ff5470', accent:'#ffc857', pants:'#532b52', hairColor:'#4b2430' },
    forest: { shirt:'#146b52', accent:'#70e000', pants:'#173d35', hairColor:'#27341f' },
    mono: { shirt:'#20263a', accent:'#f5f7ff', pants:'#111521', hairColor:'#0b0e16' }
  };
  const validHairStyles = ['spikes', 'cap', 'none'];
  const validOutfits = ['classic', 'stripe', 'hoodie', 'cyber'];
  const validFaces = ['smile', 'cool', 'wink', 'robot'];
  const isHexColor = value => /^#[0-9a-f]{6}$/i.test(String(value || ''));

  function skinFromProfile() {
    return {
      name: 'My First Skin', skin: profile.skin || '#f5b640', shirt: profile.shirt || '#7557ff',
      accent: profile.accent || '#55e6ff', pants: profile.pants || '#28325e', hairColor: profile.hairColor || '#2b1b18',
      hair: validHairStyles.includes(profile.hair) ? profile.hair : 'spikes',
      outfit: validOutfits.includes(profile.outfit) ? profile.outfit : 'classic',
      face: validFaces.includes(profile.face) ? profile.face : 'smile'
    };
  }

  function cleanSkin(candidate) {
    const fallback = skinFromProfile();
    const source = candidate && typeof candidate === 'object' ? candidate : {};
    return {
      name: String(source.name || fallback.name).trim().slice(0, 24) || fallback.name,
      ...Object.fromEntries(skinKeys.map(key => [key, isHexColor(source[key]) ? source[key].toLowerCase() : fallback[key]])),
      hair: validHairStyles.includes(source.hair) ? source.hair : fallback.hair,
      outfit: validOutfits.includes(source.outfit) ? source.outfit : fallback.outfit,
      face: validFaces.includes(source.face) ? source.face : fallback.face
    };
  }

  function applySkinPreview(skin) {
    const avatar = $('#skinStudioAvatar');
    if (!avatar || !skin) return;
    avatar.style.setProperty('--skin', skin.skin);
    avatar.style.setProperty('--shirt', skin.shirt);
    avatar.style.setProperty('--accent', skin.accent);
    avatar.style.setProperty('--pants', skin.pants);
    avatar.style.setProperty('--hair-color', skin.hairColor);
    avatar.dataset.hair = skin.hair;
    avatar.dataset.outfit = skin.outfit;
    avatar.dataset.face = skin.face;
  }

  function syncSkinLab() {
    if (!$('#skinStudioAvatar')) return;
    skinDraft = cleanSkin(skinDraft || skinFromProfile());
    $('#skinName').value = skinDraft.name;
    $$('[data-skin-color]').forEach(input => { input.value = skinDraft[input.dataset.skinColor]; });
    $$('#skinHairStyles button').forEach(button => button.classList.toggle('active', button.dataset.hair === skinDraft.hair));
    $$('#skinOutfitStyles button').forEach(button => button.classList.toggle('active', button.dataset.outfit === skinDraft.outfit));
    $$('#skinFaceStyles button').forEach(button => button.classList.toggle('active', button.dataset.face === skinDraft.face));
    applySkinPreview(skinDraft);
    renderSkinLibrary();
  }

  function setSkinMessage(message, error = false) {
    const element = $('#skinMessage');
    element.textContent = message;
    element.classList.toggle('error', error);
  }

  function renderSkinLibrary() {
    const library = $('#skinLibrary');
    if (!library) return;
    const skins = Array.isArray(profile.customSkins) ? profile.customSkins : [];
    $('#skinLibraryCount').textContent = `${skins.length} / 12`;
    if (!skins.length) {
      library.innerHTML = '<div class="skin-library-empty">Your uploaded skins will appear here. Make something unmistakably yours.</div>';
      return;
    }
    library.innerHTML = skins.map(skin => {
      const equipped = skin.id === profile.equippedSkin;
      return `<article class="skin-card ${equipped ? 'equipped' : ''}" data-skin-id="${escapeHTML(skin.id)}"><div class="skin-card-preview"><i style="--card-color:${skin.skin}"></i><i style="--card-color:${skin.shirt}"></i><i style="--card-color:${skin.accent}"></i><i style="--card-color:${skin.pants}"></i><i style="--card-color:${skin.hairColor}"></i></div><div class="skin-card-info"><b>${escapeHTML(skin.name)}</b><small>${escapeHTML(skin.outfit)} outfit • ${escapeHTML(skin.face)} face</small><div class="skin-card-actions"><button type="button" data-skin-equip>${equipped ? '✓ EQUIPPED' : 'EQUIP'}</button><button type="button" data-skin-delete aria-label="Delete skin">×</button></div></div></article>`;
    }).join('');
  }

  function applySkinToProfile(skin) {
    skinKeys.forEach(key => { profile[key] = skin[key]; });
    profile.hair = skin.hair;
    profile.outfit = skin.outfit;
    profile.face = skin.face;
  }

  function fileSafeName(name) {
    return String(name || 'robox-skin').trim().replace(/[^a-z0-9_-]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'robox-skin';
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function drawSkinPng(skin) {
    const canvas = document.createElement('canvas');
    canvas.width = 640; canvas.height = 640;
    const ctx = canvas.getContext('2d');
    const rounded = (x, y, w, h, r, color) => { ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill(); };
    const gradient = ctx.createLinearGradient(0, 0, 640, 640); gradient.addColorStop(0, '#202950'); gradient.addColorStop(1, '#090e1b'); ctx.fillStyle = gradient; ctx.fillRect(0, 0, 640, 640);
    ctx.strokeStyle = '#ffffff0d'; ctx.lineWidth = 1; for (let i = 0; i <= 640; i += 40) { ctx.beginPath(); ctx.moveTo(i,0); ctx.lineTo(i,640); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0,i); ctx.lineTo(640,i); ctx.stroke(); }
    ctx.save(); ctx.shadowColor = skin.accent; ctx.shadowBlur = 55; rounded(233, 450, 174, 40, 20, '#343b66'); ctx.restore();
    rounded(245, 105, 150, 137, 22, skin.skin); rounded(220, 255, 200, 185, 18, skin.shirt); rounded(165, 264, 47, 194, 14, skin.skin); rounded(428, 264, 47, 194, 14, skin.skin); rounded(235, 424, 78, 153, 13, skin.pants); rounded(327, 424, 78, 153, 13, skin.pants);
    ctx.fillStyle = '#202332'; rounded(278, 164, 13, 18, 7, '#202332'); rounded(349, 164, 13, 18, 7, '#202332');
    ctx.strokeStyle = skin.face === 'robot' ? skin.accent : '#784936'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(320, 188, 24, .15, Math.PI - .15); ctx.stroke();
    if (skin.hair !== 'none') { ctx.fillStyle = skin.hairColor; ctx.beginPath(); ctx.moveTo(238,140); ctx.lineTo(250,91); ctx.lineTo(276,121); ctx.lineTo(301,82); ctx.lineTo(326,121); ctx.lineTo(356,88); ctx.lineTo(388,140); ctx.closePath(); ctx.fill(); if (skin.hair === 'cap') rounded(240, 91, 157, 52, 24, skin.hairColor); }
    if (skin.outfit === 'classic') { ctx.fillStyle = '#fff'; ctx.font = 'bold 80px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('R', 320, 375); }
    if (skin.outfit === 'stripe') rounded(305, 255, 30, 185, 0, skin.accent);
    if (skin.outfit === 'hoodie') { ctx.strokeStyle = skin.accent; ctx.lineWidth = 10; ctx.beginPath(); ctx.arc(320, 270, 65, 0, Math.PI); ctx.stroke(); }
    if (skin.outfit === 'cyber') { ctx.strokeStyle = skin.accent; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(260,340); ctx.lineTo(300,340); ctx.lineTo(320,300); ctx.lineTo(345,380); ctx.lineTo(385,380); ctx.stroke(); }
    ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.font = '700 18px sans-serif'; ctx.fillText('ROBOX • SKIN LAB', 35, 45); ctx.font = '800 29px sans-serif'; ctx.fillText(skin.name, 35, 605);
    return canvas;
  }

  $$('[data-skin-tab]').forEach(button => button.addEventListener('click', () => {
    $$('[data-skin-tab]').forEach(item => item.classList.toggle('active', item === button));
    $$('[data-skin-panel]').forEach(panel => panel.classList.toggle('active', panel.dataset.skinPanel === button.dataset.skinTab));
  }));
  $$('[data-skin-color]').forEach(input => input.addEventListener('input', () => {
    skinDraft[input.dataset.skinColor] = input.value; applySkinPreview(skinDraft); setSkinMessage('Preview updated — upload when you are ready.');
  }));
  $('#skinName').addEventListener('input', event => { skinDraft.name = event.target.value.slice(0, 24); });
  $('#skinPalettes').addEventListener('click', event => {
    const button = event.target.closest('[data-palette]'); if (!button) return;
    Object.assign(skinDraft, skinPalettes[button.dataset.palette]); syncSkinLab(); beep(620);
  });
  $('#skinOutfitStyles').addEventListener('click', event => {
    const button = event.target.closest('[data-outfit]'); if (!button) return;
    skinDraft.outfit = button.dataset.outfit; syncSkinLab(); beep(620);
  });
  $('#skinFaceStyles').addEventListener('click', event => {
    const button = event.target.closest('[data-face]'); if (!button) return;
    skinDraft.face = button.dataset.face; syncSkinLab(); beep(650);
  });
  $('#skinHairStyles').addEventListener('click', event => {
    const button = event.target.closest('[data-hair]'); if (!button) return;
    skinDraft.hair = button.dataset.hair; syncSkinLab(); beep(600);
  });
  $('#resetSkinDraft').addEventListener('click', () => { skinDraft = skinFromProfile(); syncSkinLab(); setSkinMessage('Draft reset to your equipped look.'); });

  $('#publishSkin').addEventListener('click', event => {
    skinDraft.name = $('#skinName').value.trim().slice(0, 24);
    if (skinDraft.name.length < 2) { setSkinMessage('Give your skin a name with at least 2 characters.', true); return; }
    if (!Array.isArray(profile.customSkins)) profile.customSkins = [];
    const existing = profile.customSkins.find(item => item.name.toLowerCase() === skinDraft.name.toLowerCase());
    const record = { ...cleanSkin(skinDraft), id: existing?.id || `skin-${Date.now()}`, updatedAt: new Date().toISOString() };
    profile.customSkins = [record, ...profile.customSkins.filter(item => item.id !== record.id)].slice(0, 12);
    profile.equippedSkin = record.id; applySkinToProfile(record); skinDraft = { ...record }; saveProfile(); syncSkinLab();
    event.currentTarget.textContent = '✓ UPLOADED & EQUIPPED'; setSkinMessage(`${record.name} is live on your Robox profile.`); showToast('Skin uploaded!', `${record.name} is now equipped`); beep(920, .16);
    setTimeout(() => { event.currentTarget.textContent = 'UPLOAD TO ROBOX'; }, 1500);
  });

  $('#exportSkin').addEventListener('click', () => {
    skinDraft.name = $('#skinName').value.trim().slice(0, 24) || 'My Skin';
    const packageData = { format:'robox-skin', version:1, createdBy:profile.name, exportedAt:new Date().toISOString(), skin:cleanSkin(skinDraft) };
    downloadBlob(new Blob([JSON.stringify(packageData, null, 2)], { type:'application/json' }), `${fileSafeName(skinDraft.name)}.roboxskin`);
    setSkinMessage('Skin file exported. Import it on another device anytime.');
  });
  $('#downloadSkinPng').addEventListener('click', () => {
    skinDraft.name = $('#skinName').value.trim().slice(0, 24) || 'My Skin';
    drawSkinPng(cleanSkin(skinDraft)).toBlob(blob => downloadBlob(blob, `${fileSafeName(skinDraft.name)}.png`), 'image/png'); setSkinMessage('PNG preview downloaded.');
  });
  $('#importSkin').addEventListener('click', () => $('#skinFileInput').click());
  $('#skinFileInput').addEventListener('change', event => {
    const file = event.target.files?.[0]; if (!file) return;
    if (file.size > 100000) { setSkinMessage('That skin file is too large.', true); event.target.value = ''; return; }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result); const incoming = parsed.format === 'robox-skin' ? parsed.skin : parsed;
        if (!incoming || !skinKeys.every(key => isHexColor(incoming[key]))) throw new Error('invalid');
        skinDraft = cleanSkin(incoming); syncSkinLab(); setSkinMessage(`${skinDraft.name} imported — preview it, then upload.`); beep(760);
      } catch (_) { setSkinMessage('This is not a valid .roboxskin file.', true); }
      event.target.value = '';
    };
    reader.onerror = () => { setSkinMessage('The skin file could not be read.', true); event.target.value = ''; };
    reader.readAsText(file);
  });

  $('#skinLibrary').addEventListener('click', event => {
    const card = event.target.closest('[data-skin-id]'); if (!card) return;
    const selected = (profile.customSkins || []).find(item => item.id === card.dataset.skinId); if (!selected) return;
    if (event.target.closest('[data-skin-delete]')) {
      profile.customSkins = profile.customSkins.filter(item => item.id !== selected.id);
      if (profile.equippedSkin === selected.id) profile.equippedSkin = null;
      saveProfile(); renderSkinLibrary(); setSkinMessage(`${selected.name} deleted.`); return;
    }
    if (event.target.closest('[data-skin-equip]')) {
      profile.equippedSkin = selected.id; applySkinToProfile(selected); skinDraft = { ...selected }; saveProfile(); syncSkinLab(); setSkinMessage(`${selected.name} equipped.`); showToast('Look equipped', selected.name); beep(860);
    }
  });

  let skinDragStart = null, skinAvatarAngle = 0;
  const skinStudioAvatar = $('#skinStudioAvatar');
  skinStudioAvatar.addEventListener('pointerdown', event => { skinDragStart = event.clientX; skinStudioAvatar.setPointerCapture(event.pointerId); });
  skinStudioAvatar.addEventListener('pointermove', event => { if (skinDragStart === null) return; skinAvatarAngle += (event.clientX - skinDragStart) * .7; skinDragStart = event.clientX; skinStudioAvatar.style.transform = `scale(1.08) rotateY(${skinAvatarAngle}deg)`; });
  skinStudioAvatar.addEventListener('pointerup', () => { skinDragStart = null; });
  $$('[data-preview-turn]').forEach(button => button.addEventListener('click', () => { skinAvatarAngle += Number(button.dataset.previewTurn); skinStudioAvatar.style.transform = `scale(1.08) rotateY(${skinAvatarAngle}deg)`; }));

  function setSwatch(group, value, key) {
    $$(group + ' button').forEach(button => button.classList.toggle('active', button.dataset.color === value));
    profile[key] = value; saveProfile(); beep(580);
  }
  $('#skinSwatches').addEventListener('click', event => { const button = event.target.closest('button'); if (button) setSwatch('#skinSwatches', button.dataset.color, 'skin'); });
  $('#shirtSwatches').addEventListener('click', event => { const button = event.target.closest('button'); if (button) setSwatch('#shirtSwatches', button.dataset.color, 'shirt'); });
  $('#hairStyles').addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button) return;
    $$('#hairStyles button').forEach(item => item.classList.toggle('active', item === button));
    profile.hair = button.dataset.hair; $('#studioAvatar .a-hair').className = `a-hair ${profile.hair}`; saveProfile(); beep(600);
  });
  syncCustomizer();
  $('#saveLook').addEventListener('click', event => { event.currentTarget.textContent = '✓ SAVED!'; beep(920, .15); setTimeout(() => event.currentTarget.textContent = '✓ LOOK EQUIPPED', 1200); });

  let dragStart = null, avatarAngle = 0;
  const studioAvatar = $('#studioAvatar');
  studioAvatar.addEventListener('pointerdown', e => { dragStart = e.clientX; studioAvatar.setPointerCapture(e.pointerId); });
  studioAvatar.addEventListener('pointermove', e => { if (dragStart === null) return; avatarAngle += (e.clientX - dragStart) * .7; dragStart = e.clientX; studioAvatar.style.transform = `rotateY(${avatarAngle}deg)`; });
  studioAvatar.addEventListener('pointerup', () => dragStart = null);

  function emptyFriendsMarkup() {
    return `<div class="friends-empty"><div class="empty-crew-icon"><span>♙</span><span>☹</span><span>♙</span></div><p class="eyebrow">YOUR CREW AWAITS</p><h3>No friends yet</h3><p>Type a player's username to add them. Real play-together joining will need multiplayer setup first.</p></div>`;
  }

  function renderFriends() {
    const list = $('#friendList');
    if (!list) return;
    const friends = Array.isArray(profile.friends) ? profile.friends : [];
    if (!friends.length) { list.innerHTML = emptyFriendsMarkup(); return; }
    list.innerHTML = friends.map(friend => {
      const name = friend.name || 'Player';
      const id = friend.id || name.toLowerCase();
      const color = friend.color || 'violet';
      return `<article class="saved" data-friend-id="${id}"><span class="friend-avatar ${color}">${name.charAt(0).toUpperCase()}</span><div><h3>${name}</h3><p>Friend • Saved player</p></div><div class="friend-card-actions"><button class="play-together-btn" data-friend-action="play-together">PLAY TOGETHER</button><button class="unfriend-btn" data-friend-action="unfriend">UNFRIEND</button></div></article>`;
    }).join('');
  }

  function petCardsMarkup() {
    const ownedPets = Array.isArray(profile.pets) ? profile.pets : [];
    return [...petCatalog, ...(Array.isArray(profile.customPets) ? profile.customPets : [])].map(pet => {
      const owned = ownedPets.includes(pet.id);
      const equipped = profile.equippedPet === pet.id;
      const label = equipped ? 'EQUIPPED' : owned ? 'EQUIP' : `GET FOR R ${pet.price}`;
      return `<article class="pet-card ${equipped ? 'equipped' : ''}"><div class="pet-art ${pet.type}" style="--pet-color:${pet.color};--pet-accent:${pet.accent}"><span>${pet.icon}</span>${equipped ? '<b>FOLLOWING YOU</b>' : ''}</div><div class="pet-info"><p class="eyebrow">${owned ? 'OWNED PET' : `R ${pet.price} ROBUX`}</p><h3>${escapeHTML(pet.name)}</h3><p>${escapeHTML(pet.description)}</p><button data-pet-id="${pet.id}" data-pet-action="${owned ? 'equip' : 'buy'}" ${equipped ? 'disabled' : ''}>${label}</button></div></article>`;
    }).join('');
  }
  function renderPets() {
    const markup = petCardsMarkup();
    ['#petGrid', '#gamePetGrid'].forEach(selector => { const grid = $(selector); if (grid) grid.innerHTML = markup; });
    const gamePetCoins = $('#gamePetCoins');
    if (gamePetCoins) gamePetCoins.textContent = profile.coins;
    renderShopItems();
  }
  function cleanShopItem(item) {
    if (!item || typeof item !== 'object') return null;
    const type = shopItemTypeIcons[item.type] ? item.type : 'trophy';
    const price = readWholeAmount(item.price);
    const name = String(item.name || '').trim().slice(0, 18);
    if (!name || !price) return null;
    const owner = String(item.owner || 'Robox Creator').trim().slice(0, 16) || 'Robox Creator';
    const color = /^#[0-9a-f]{6}$/i.test(String(item.color || '')) ? item.color : '#ff7ab6';
    return {
      id: String(item.id || `shop-${Date.now()}`),
      name,
      type,
      icon: shopItemTypeIcons[type],
      price,
      color,
      description: String(item.description || `A custom ${type} made for the shop.`).trim().slice(0, 80),
      owner,
      ownerKey: String(item.ownerKey || owner).toLowerCase(),
      createdAt: item.createdAt || new Date().toISOString()
    };
  }
  function shopItemsCatalog() {
    return readPlayerShopItems().map(cleanShopItem).filter(Boolean).slice(0, 80);
  }
  function shopItemCardsMarkup() {
    const items = shopItemsCatalog();
    if (!items.length) return `<div class="shop-items-empty"><span>✦</span><b>No creator items yet</b><small>Make something on the Pets page, then it will show up here.</small></div>`;
    const ownedItems = Array.isArray(profile.ownedShopItems) ? profile.ownedShopItems : [];
    return items.map(item => {
      const owned = ownedItems.includes(item.id);
      const madeByYou = item.ownerKey === String(profile.name || '').toLowerCase();
      const label = owned ? 'OWNED' : `BUY FOR R ${formatRobux(item.price)}`;
      return `<article class="shop-item-card ${owned ? 'owned' : ''}" style="--item-color:${escapeHTML(item.color)}"><div class="shop-item-art"><span>${escapeHTML(item.icon)}</span></div><div class="shop-item-info"><p class="eyebrow">${madeByYou ? 'YOUR CREATION' : `R ${formatRobux(item.price)} ROBUX`}</p><h3>${escapeHTML(item.name)}</h3><p>${escapeHTML(item.description)}</p><small>By ${escapeHTML(item.owner)}</small><button data-shop-item-id="${escapeHTML(item.id)}" ${owned ? 'disabled' : ''}>${label}</button></div></article>`;
    }).join('');
  }
  function renderShopItems() {
    const items = shopItemsCatalog();
    const mine = items.filter(item => item.ownerKey === String(profile.name || '').toLowerCase());
    const count = $('#shopItemCount');
    if (count) count.textContent = `${mine.length} by you • ${items.length} in shop`;
    const created = $('#createdShopItems');
    if (created) {
      created.innerHTML = mine.length ? mine.map(item => `<article class="created-shop-item" style="--item-color:${escapeHTML(item.color)}"><span>${escapeHTML(item.icon)}</span><div><b>${escapeHTML(item.name)}</b><small>In shop for R ${formatRobux(item.price)}</small></div><button data-delete-shop-item="${escapeHTML(item.id)}">DELETE</button></article>`).join('') : `<div class="created-shop-empty">No items made by you yet. Fill out the maker above and press Put In Shop.</div>`;
    }
    const grid = $('#gameShopItemGrid');
    if (grid) grid.innerHTML = shopItemCardsMarkup();
    const gamePetCoins = $('#gamePetCoins');
    if (gamePetCoins) gamePetCoins.textContent = profile.coins;
  }
  function createShopItem(event) {
    event.preventDefault();
    const message = $('#shopItemMessage');
    if (sessionMode !== 'account') { message.textContent = 'Create or sign in to an account before making shop items.'; beep(240, .12); return; }
    const name = $('#shopItemName').value.trim();
    const price = readWholeAmount($('#shopItemPrice').value);
    if (name.length < 2) { message.textContent = 'Give your shop item a name with at least 2 characters.'; return; }
    if (!price) { message.textContent = 'Set a Robux price of 1 or more.'; return; }
    const type = $('#shopItemType').value;
    const item = cleanShopItem({
      id:`shop-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      name,
      type,
      price,
      color:$('#shopItemColor').value,
      description:$('#shopItemDescription').value.trim() || `A custom ${type} made by ${profile.name}.`,
      owner:profile.name,
      ownerKey:String(profile.name || '').toLowerCase(),
      createdAt:new Date().toISOString()
    });
    if (!item) { message.textContent = 'This shop item could not be created.'; return; }
    const items = shopItemsCatalog().filter(entry => entry.id !== item.id);
    writePlayerShopItems([item, ...items].slice(0, 80));
    if (!Array.isArray(profile.ownedShopItems)) profile.ownedShopItems = [];
    profile.ownedShopItems = [...new Set([item.id, ...profile.ownedShopItems])];
    saveProfile(`Created shop item ${item.name}`);
    $('#shopItemName').value = '';
    $('#shopItemDescription').value = '';
    message.textContent = `${item.name} is now in the shop for R ${formatRobux(item.price)}.`;
    renderShopItems();
    showToast('Item added to shop!', `${item.name} costs R ${formatRobux(item.price)}`);
    beep(980, .18);
  }
  function buyShopItem(itemId) {
    const item = shopItemsCatalog().find(entry => entry.id === itemId);
    if (!item) return;
    if (!Array.isArray(profile.ownedShopItems)) profile.ownedShopItems = [];
    if (profile.ownedShopItems.includes(item.id)) return;
    if (profile.coins < item.price) {
      $('#gameShopItemMessage').textContent = `You need R ${formatRobux(item.price - profile.coins)} more for ${item.name}.`;
      showToast('Not enough Robux', `Need R ${formatRobux(item.price)}`);
      beep(240, .12);
      return;
    }
    profile.coins -= item.price;
    profile.ownedShopItems.push(item.id);
    saveProfile(`Bought shop item ${item.name}`);
    $('#gameShopItemMessage').textContent = `${item.name} bought for R ${formatRobux(item.price)}.`;
    renderShopItems();
    showToast(`${item.name} bought!`, `Made by ${item.owner}`);
    beep(1050, .16);
  }
  function deleteShopItem(itemId) {
    const item = shopItemsCatalog().find(entry => entry.id === itemId);
    if (!item || item.ownerKey !== String(profile.name || '').toLowerCase()) return;
    writePlayerShopItems(shopItemsCatalog().filter(entry => entry.id !== itemId));
    renderShopItems();
    $('#shopItemMessage').textContent = `${item.name} was removed from the shop.`;
    showToast('Removed from shop', item.name);
    beep(420, .1);
  }
  function handlePetAction(event) {
    const button = event.target.closest('[data-pet-id]');
    if (!button) return;
    const pet = [...petCatalog, ...(profile.customPets || [])].find(item => item.id === button.dataset.petId);
    if (!pet) return;
    if (!Array.isArray(profile.pets)) profile.pets = [];
    if (button.dataset.petAction === 'buy') {
      if (profile.coins < pet.price) { showToast('Not enough Robux', `You need R ${pet.price - profile.coins} more for ${pet.name}`); beep(240, .12); return; }
      profile.coins -= pet.price;
      profile.pets.push(pet.id);
      profile.equippedPet = pet.id;
      saveProfile();
      showToast(`${pet.name} unlocked!`, `R ${pet.price} Robux paid • Pet equipped`);
      beep(980, .18);
      return;
    }
    if (profile.pets.includes(pet.id)) {
      profile.equippedPet = pet.id;
      saveProfile();
      showToast(`${pet.name} equipped`, 'Your pet will follow you into worlds');
      beep(820, .12);
    }
  }
  $('#petGrid').addEventListener('click', handlePetAction);
  $('#gamePetGrid').addEventListener('click', handlePetAction);
  $('#shopItemForm').addEventListener('submit', createShopItem);
  $('#createdShopItems').addEventListener('click', event => {
    const button = event.target.closest('[data-delete-shop-item]');
    if (button) deleteShopItem(button.dataset.deleteShopItem);
  });
  $('#gameShopItemGrid').addEventListener('click', event => {
    const button = event.target.closest('[data-shop-item-id]');
    if (button && !button.disabled) buyShopItem(button.dataset.shopItemId);
  });

  const customPetIcons = { pup:'🐶', cat:'🐱', bot:'🤖', dragon:'🐉' };
  function updatePetDesignerPreview() {
    const type = $('input[name="customPetType"]:checked')?.value || 'pup';
    const name = $('#customPetName').value.trim() || 'MY PET';
    $('#designerPetIcon').textContent = customPetIcons[type];
    $('#designerPetName').textContent = name.toUpperCase();
    $('#designerStage').style.setProperty('--pet-color', $('#customPetColor').value);
    $('#designerStage').style.setProperty('--pet-accent', $('#customPetAccent').value);
  }
  $('#openPetDesigner').addEventListener('click', () => { $('#designerMessage').textContent = ''; updatePetDesignerPreview(); switchView('petDesign'); });
  $('#backToPets').addEventListener('click', () => switchView('pets'));
  $('#customPetName').addEventListener('input', updatePetDesignerPreview);
  $('#customPetColor').addEventListener('input', updatePetDesignerPreview);
  $('#customPetAccent').addEventListener('input', updatePetDesignerPreview);
  $$('input[name="customPetType"]').forEach(input => input.addEventListener('change', updatePetDesignerPreview));
  $('#petDesignerForm').addEventListener('submit', event => {
    event.preventDefault();
    const message = $('#designerMessage'), name = $('#customPetName').value.trim();
    if (sessionMode !== 'account') { message.textContent = 'Create or sign in to an account before designing a pet.'; beep(240, .12); return; }
    if (name.length < 2) { message.textContent = 'Give your pet a name with at least 2 characters.'; return; }
    if (profile.coins < 1000) { message.textContent = `You need R ${1000 - profile.coins} more Robux to create this pet.`; beep(240, .12); return; }
    const type = $('input[name="customPetType"]:checked')?.value || 'pup';
    const customPet = { id:`custom-${Date.now()}`, name, type, icon:customPetIcons[type], price:1000, color:$('#customPetColor').value, accent:$('#customPetAccent').value, description:`A one-of-a-kind ${type} designed by ${profile.name}.`, custom:true };
    profile.coins -= 1000;
    profile.customPets.push(customPet);
    profile.pets.push(customPet.id);
    profile.equippedPet = customPet.id;
    saveProfile();
    $('#customPetName').value = '';
    message.textContent = '';
    switchView('pets');
    showToast(`${customPet.name} created!`, 'R 1,000 Robux paid • Custom pet equipped');
    beep(1080, .2);
  });

  function cleanWorldSize(value) {
    const size = Math.floor(Number(value));
    return Number.isFinite(size) ? Math.max(12, size) : 12;
  }
  function worldConfigFromRecord(record) {
    const theme = worldThemes[record.theme] || worldThemes.grass;
    return {
      id: record.id, name: record.name.toUpperCase(), icon: theme.icon, sky: theme.sky,
      ground: theme.ground, side: theme.side, accent: theme.accent,
      quest: 'Your First Adventure', text: 'Collect 5 builder tokens'
    };
  }
  function cleanWorldFileBlock(block, size) {
    const x = Math.floor(Number(block?.x));
    const y = Math.floor(Number(block?.y));
    const h = Math.max(1, Math.min(4, Math.floor(Number(block?.h) || 1)));
    const type = Math.max(1, Math.min(4, Math.floor(Number(block?.type) || 1)));
    if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= size || y >= size) return null;
    return { x, y, h, type };
  }
  function worldFileTemplateData() {
    return {
      format:'robox-world',
      version:1,
      instructions:'Edit this file, save it as .roboxworld, then import it in Robox to create a world.',
      world:{
        name:'My File World',
        description:'A world made from a file.',
        theme:'grass',
        size:12,
        brainrotMode:false,
        baseGame:false,
        brainrots:[
          { name:'Example Brainrot', tag:'EB', color:'#ffcf5a', accent:'#54edff', value:1 }
        ],
        blocks:[
          { x:5, y:5, h:2, type:3 },
          { x:6, y:5, h:1, type:4 },
          { x:5, y:6, h:1, type:2 }
        ]
      }
    };
  }
  function worldFileFromRecord(world) {
    return {
      format:'robox-world',
      version:1,
      exportedAt:new Date().toISOString(),
      world:{
        name:world.name,
        description:world.description || '',
        theme:worldThemes[world.theme] ? world.theme : 'grass',
        size:cleanWorldSize(world.size),
        brainrotMode:!!world.brainrotMode || isBrainrotWorldRecord(world),
        baseGame:!!world.baseGame || isBrainrotWorldRecord(world),
        brainrotScore:Math.max(0, Math.floor(Number(world.brainrotScore) || 0)),
        brainrots:Array.isArray(world.brainrots) ? world.brainrots.map(item => ({
          name:String(item.name || 'Brainrot').slice(0, 24),
          tag:String(item.tag || item.name || 'BR').replace(/[^A-Za-z0-9]/g, '').slice(0, 2).toUpperCase() || 'BR',
          color:item.color || '#ffcf5a',
          accent:item.accent || '#54edff',
          value:Math.max(1, Math.min(10, Math.floor(Number(item.value) || 1)))
        })) : [],
        blocks:Array.isArray(world.blocks) ? world.blocks.map(block => ({ x:block.x, y:block.y, h:block.h, type:block.type })) : []
      }
    };
  }
  function worldRecordFromFileData(data, fileName = 'world file') {
    const source = data?.format === 'robox-world' && data.world ? data.world : data;
    if (!source || typeof source !== 'object') throw new Error('This is not a Robox world file.');
    const name = String(source.name || '').trim().slice(0, 32);
    if (name.length < 3) throw new Error('World files need a name with at least 3 characters.');
    const description = String(source.description || `Imported from ${fileName}`).trim().slice(0, 100);
    const theme = worldThemes[source.theme] ? source.theme : 'grass';
    const size = cleanWorldSize(source.size);
    const blocks = Array.isArray(source.blocks)
      ? source.blocks.map(block => cleanWorldFileBlock(block, size)).filter(Boolean).slice(0, size * size)
      : [];
    const brainrots = Array.isArray(source.brainrots)
      ? source.brainrots.filter(item => item && item.name).map(item => ({
        name:String(item.name || 'Brainrot').slice(0, 24),
        tag:String(item.tag || item.name || 'BR').replace(/[^A-Za-z0-9]/g, '').slice(0, 2).toUpperCase() || 'BR',
        color:item.color || '#ffcf5a',
        accent:item.accent || '#54edff',
        value:Math.max(1, Math.min(10, Math.floor(Number(item.value) || 1)))
      })).slice(0, 12)
      : [];
    const brainrotMode = !!source.brainrotMode || !!source.baseGame || `${name} ${description}`.toLowerCase().includes('brainrot');
    return {
      id:`world-file-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
      name,
      description,
      theme,
      visits:0,
      blocks:blocks.length ? blocks : null,
      size,
      brainrotMode,
      baseGame:brainrotMode,
      brainrots,
      brainrotScore:0,
      invites:[],
      published:false,
      importedFrom:fileName,
      createdAt:new Date().toISOString()
    };
  }
  function downloadWorldTemplateFile() {
    downloadBlob(new Blob([JSON.stringify(worldFileTemplateData(), null, 2)], { type:'application/json' }), 'robox-world-template.roboxworld');
    showToast('World file template downloaded', 'Edit it, then import it into Robox');
    beep(780, .12);
  }
  function exportWorldFile(worldId) {
    const world = profile.worlds.find(item => item.id === worldId);
    if (!world) return;
    downloadBlob(new Blob([JSON.stringify(worldFileFromRecord(world), null, 2)], { type:'application/json' }), `${fileSafeName(world.name)}.roboxworld`);
    showToast('World file exported', `${world.name} downloaded`);
    beep(780, .12);
  }
  function importWorldFile(file) {
    if (!file) return;
    if (file.size > 1000000) { showToast('World file too large', 'Keep world files under 1 MB'); $('#worldFileInput').value = ''; return; }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const importedWorld = worldRecordFromFileData(JSON.parse(reader.result), file.name || 'world file');
        if (!Array.isArray(profile.worlds)) profile.worlds = [];
        profile.worlds.unshift(importedWorld);
        profile.deletedWorldIds = profile.deletedWorldIds.filter(id => id !== importedWorld.id);
        saveProfile();
        switchView('discover');
        showToast('World file imported!', `${importedWorld.name} is now a draft`);
        beep(980, .18);
      } catch (error) {
        showToast('Could not import world', error.message || 'Check the file and try again');
        beep(240, .12);
      } finally {
        $('#worldFileInput').value = '';
      }
    };
    reader.onerror = () => {
      showToast('Could not read file', 'Try saving it again as .roboxworld');
      $('#worldFileInput').value = '';
    };
    reader.readAsText(file);
  }

  function emptyWorldsMarkup() {
    if (sessionMode === 'guest') {
      const saved = readSavedAccount();
      const savedName = saved?.username?.toLowerCase();
      const savedWorlds = saved?.profile?.worlds || [];
      const backupWorlds = savedName ? readWorldLibrary()[savedName]?.worlds || [] : [];
      if (savedWorlds.length || backupWorlds.length) return `<div class="worlds-empty"><div class="empty-world-visual" aria-hidden="true"><span></span><i>↪</i><b></b></div><p class="eyebrow">WORLDS FOUND</p><h3>Sign in to see your worlds</h3><p>Your saved creations belong to ${escapeHTML(saved.username)}. Sign out of guest mode and enter that account to restore them here.</p></div>`;
    }
    return `<div class="worlds-empty"><div class="empty-world-visual" aria-hidden="true"><span></span><i>＋</i><b></b></div><p class="eyebrow">CLEAN SLATE</p><h3>No worlds yet</h3><p>Create your first world, choose its environment, then jump in and build it your way.</p></div>`;
  }

  function renderWorlds() {
    const grid = $('#gameGrid');
    if (!grid) return;
    const createdWorlds = Array.isArray(profile.worlds) ? profile.worlds : [];
    if (!createdWorlds.length) { grid.innerHTML = emptyWorldsMarkup(); return; }
    grid.innerHTML = createdWorlds.map(world => {
      const theme = worldThemes[world.theme] || worldThemes.grass;
      const name = escapeHTML(world.name);
      const description = escapeHTML(world.description || 'A world ready to be shaped.');
      const status = world.published ? 'LIVE' : 'DRAFT';
      const publishLabel = world.published ? 'UPDATE LIVE' : 'PUBLISH GAME';
      return `<article class="game-card user-world-card" data-title="${name.toLowerCase()}"><div class="game-art user-world-art ${world.theme || 'grass'}"><span class="world-owner">CREATED BY YOU</span><span class="world-status ${world.published ? 'live' : 'draft'}">${status}</span></div><div class="game-info"><h4>${name}</h4><p>${description}</p><div><span>${theme.icon} ${theme.label}</span><span>◆ ${world.visits || 0} plays</span></div></div><button class="world-publish-btn" data-world-publish="${world.id}">${publishLabel}</button><button class="world-delete-btn" data-world-delete="${world.id}" aria-label="Delete ${name}">DELETE</button><button class="card-play" data-world-id="${world.id}" aria-label="Play ${name}">▶</button></article>`;
    }).join('');
    $$('.user-world-card', grid).forEach((card, index) => {
      const world = createdWorlds[index];
      const accessButton = document.createElement('button');
      accessButton.className = 'world-access-btn';
      accessButton.dataset.worldAccess = world.id;
      accessButton.textContent = 'INVITE PLAYERS';
      card.append(accessButton);
      const fileButton = document.createElement('button');
      fileButton.className = 'world-file-btn';
      fileButton.dataset.worldExport = world.id;
      fileButton.textContent = 'EXPORT FILE';
      card.append(fileButton);
      if (world.published) {
        const roomButton = document.createElement('button');
        roomButton.className = 'world-room-owner-btn';
        roomButton.dataset.createRoom = world.id;
        roomButton.textContent = '◎ CREATE ROOM';
        card.append(roomButton);
      }
    });
  }

  function renderPublishedGames() {
    const grid = $('#publishedGamesGrid');
    if (!grid) return;
    const games = readPublishedGames();
    if (!games.length) {
      grid.innerHTML = `<div class="worlds-empty published-empty"><div class="empty-world-visual" aria-hidden="true"><span></span><i>▲</i><b></b></div><p class="eyebrow">NOTHING LIVE YET</p><h3>No published games</h3><p>Publish one of your draft worlds and it will appear here for players to discover.</p></div>`;
      return;
    }
    grid.innerHTML = games.map(world => {
      const theme = worldThemes[world.theme] || worldThemes.grass;
      const name = escapeHTML(world.name);
      const owner = escapeHTML(world.owner || 'Robox Creator');
      const description = escapeHTML(world.description || 'A player-created game.');
      return `<article class="game-card user-world-card published-game-card" data-title="${name.toLowerCase()} ${owner.toLowerCase()}"><div class="game-art user-world-art ${world.theme || 'grass'}"><span class="world-owner">BY ${owner}</span><span class="world-status live">LIVE</span></div><div class="game-info"><h4>${name}</h4><p>${description}</p><div><span>${theme.icon} ${theme.label}</span><span>◆ ${world.plays || 0} plays</span></div></div><div class="public-room-actions"><button type="button" data-create-room="${world.id}">CREATE ROOM</button><button type="button" data-join-public="${world.id}">JOIN PUBLIC</button></div><div class="public-room-list" data-public-rooms-for="${world.id}"><span>Checking rooms…</span></div><button class="card-play" data-published-world-id="${world.id}" aria-label="Join public game ${name}">▶</button></article>`;
    }).join('');
    $$('.published-game-card', grid).forEach((card, index) => {
      const invites = Array.isArray(games[index].invites) ? games[index].invites : [];
      const invite = invites.find(item => String(item.username || '').toLowerCase() === profile.name.toLowerCase());
      if (!invite) return;
      const badge = document.createElement('span');
      badge.className = `invite-access-badge ${invite.canBuild ? 'builder' : 'player'}`;
      badge.textContent = invite.canBuild ? 'BUILD ACCESS' : 'INVITED';
      $('.game-art', card).append(badge);
    });
    refreshPublicRoomCards();
  }

  const createWorldModal = $('#createWorldModal');
  const deleteWorldModal = $('#deleteWorldModal');
  const publishWorldModal = $('#publishWorldModal');
  const worldAccessModal = $('#worldAccessModal');
  let pendingDeleteWorldId = null;
  let pendingPublishWorldId = null;
  let accessWorldId = null;
  function getAccessWorld() { return profile.worlds.find(world => world.id === accessWorldId); }
  function syncWorldInvites(world) {
    if (!world.published) return;
    const published = readPublishedGames();
    const liveWorld = published.find(item => item.id === world.id);
    if (liveWorld) {
      liveWorld.invites = world.invites.map(invite => ({ ...invite }));
      writePublishedGames(published);
      renderPublishedGames();
    }
  }
  function renderInvitedPlayers() {
    const world = getAccessWorld();
    const list = $('#invitedPlayersList');
    if (!world) { list.innerHTML = ''; return; }
    if (!Array.isArray(world.invites)) world.invites = [];
    if (!world.invites.length) {
      list.innerHTML = '<div class="access-empty"><b>No players invited yet</b><small>Invite someone by their exact username.</small></div>';
      return;
    }
    list.innerHTML = world.invites.map(invite => `<div class="access-player" data-invite-user="${invite.username.toLowerCase()}"><span class="access-avatar">${escapeHTML(invite.username.charAt(0).toUpperCase())}</span><div><b>${escapeHTML(invite.username)}</b><small>Invited player</small></div><label class="permission-toggle"><input type="checkbox" data-invite-build ${invite.canBuild ? 'checked' : ''}><span>Can build</span></label><button data-remove-invite>REMOVE</button></div>`).join('');
  }
  function openWorldAccess(worldId) {
    const world = profile.worlds.find(item => item.id === worldId);
    if (!world) return;
    accessWorldId = worldId;
    if (!Array.isArray(world.invites)) world.invites = [];
    $('#accessWorldName').textContent = world.name;
    $('#inviteUsernameInput').value = '';
    $('#inviteCanBuild').checked = false;
    $('#invitePlayerMessage').textContent = '';
    renderInvitedPlayers();
    worldAccessModal.classList.add('show');
    $('#inviteUsernameInput').focus();
  }
  function closeWorldAccess() {
    accessWorldId = null;
    worldAccessModal.classList.remove('show');
  }
  function closeWorldCreator() {
    createWorldModal.classList.remove('show');
    $('#createWorldForm').reset();
    $('#worldCreateMessage').textContent = '';
  }
  $('#createWorldBtn').addEventListener('click', () => {
    createWorldModal.classList.add('show');
    $('#worldNameInput').focus();
    beep(720);
  });
  $('#downloadWorldTemplateBtn').addEventListener('click', downloadWorldTemplateFile);
  $('#importWorldFileBtn').addEventListener('click', () => $('#worldFileInput').click());
  $('#worldFileInput').addEventListener('change', event => importWorldFile(event.target.files?.[0]));
  $$('[data-close-world]').forEach(button => button.addEventListener('click', closeWorldCreator));
  createWorldModal.addEventListener('click', event => { if (event.target === createWorldModal) closeWorldCreator(); });
  $('#createWorldForm').addEventListener('submit', event => {
    event.preventDefault();
    const name = $('#worldNameInput').value.trim();
    const description = $('#worldDescriptionInput').value.trim();
    const theme = $('input[name="worldTheme"]:checked').value;
    if (name.length < 3) { $('#worldCreateMessage').textContent = 'World names need at least 3 characters.'; return; }
    const brainrotMode = `${name} ${description}`.toLowerCase().includes('brainrot');
    profile.worlds.push({ id:`world-${Date.now().toString(36)}`, name, description, theme, visits:0, blocks:null, size:12, brainrotMode, baseGame:brainrotMode, brainrots:brainrotMode ? brainrotCatalog.map(item => ({ ...item })) : [], brainrotScore:0, invites:[], published:false, createdAt:new Date().toISOString() });
    saveProfile(); closeWorldCreator(); switchView('discover'); beep(920, .15);
  });
  $('#gameGrid').addEventListener('click', event => {
    const roomButton = event.target.closest('[data-create-room]');
    if (roomButton) { enterPublicRoom(roomButton.dataset.createRoom, 'create'); return; }
    const accessButton = event.target.closest('[data-world-access]');
    if (accessButton) { openWorldAccess(accessButton.dataset.worldAccess); return; }
    const exportButton = event.target.closest('[data-world-export]');
    if (exportButton) { exportWorldFile(exportButton.dataset.worldExport); return; }
    const publishButton = event.target.closest('[data-world-publish]');
    if (publishButton) {
      pendingPublishWorldId = publishButton.dataset.worldPublish;
      const world = profile.worlds.find(item => item.id === pendingPublishWorldId);
      $('#publishWorldName').textContent = world ? world.name : 'This world';
      $('#publishWorldTitle').textContent = world && world.published ? 'Update this live game?' : 'Publish this game?';
      $('#confirmPublishWorld').textContent = world && world.published ? 'UPDATE LIVE' : 'PUBLISH GAME';
      publishWorldModal.classList.add('show');
      return;
    }
    const deleteButton = event.target.closest('[data-world-delete]');
    if (deleteButton) {
      pendingDeleteWorldId = deleteButton.dataset.worldDelete;
      const world = profile.worlds.find(item => item.id === pendingDeleteWorldId);
      $('#deleteWorldName').textContent = world ? world.name : 'This world';
      deleteWorldModal.classList.add('show');
      return;
    }
    const playButton = event.target.closest('[data-world-id]');
    if (playButton) launchGame(playButton.dataset.worldId);
  });
  $$('[data-close-world-access]').forEach(button => button.addEventListener('click', closeWorldAccess));
  worldAccessModal.addEventListener('click', event => { if (event.target === worldAccessModal) closeWorldAccess(); });
  $('#invitePlayerForm').addEventListener('submit', event => {
    event.preventDefault();
    const world = getAccessWorld();
    const username = $('#inviteUsernameInput').value.trim();
    const message = $('#invitePlayerMessage');
    message.classList.remove('success');
    if (!world) return;
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) { message.textContent = 'Use 3-16 letters, numbers, or underscores.'; return; }
    if (username.toLowerCase() === profile.name.toLowerCase()) { message.textContent = 'You already own this world.'; return; }
    if (!Array.isArray(world.invites)) world.invites = [];
    const existing = world.invites.find(invite => invite.username.toLowerCase() === username.toLowerCase());
    if (existing) {
      existing.canBuild = $('#inviteCanBuild').checked;
      existing.username = username;
    } else {
      world.invites.push({ username, canBuild:$('#inviteCanBuild').checked, invitedAt:new Date().toISOString() });
    }
    saveProfile(); syncWorldInvites(world); renderInvitedPlayers();
    message.textContent = world.published ? `Invite sent to ${username}.` : `${username} is invited. Publish the game to deliver access.`;
    message.classList.add('success');
    $('#inviteUsernameInput').value = '';
    $('#inviteCanBuild').checked = false;
    beep(880, .12);
  });
  $('#invitedPlayersList').addEventListener('change', event => {
    const checkbox = event.target.closest('[data-invite-build]');
    if (!checkbox) return;
    const world = getAccessWorld();
    const row = checkbox.closest('[data-invite-user]');
    const invite = world?.invites.find(item => item.username.toLowerCase() === row.dataset.inviteUser);
    if (!invite) return;
    invite.canBuild = checkbox.checked;
    saveProfile(); syncWorldInvites(world);
    $('#invitePlayerMessage').textContent = checkbox.checked ? `${invite.username} can now build.` : `${invite.username} now has play-only access.`;
    $('#invitePlayerMessage').classList.add('success');
  });
  $('#invitedPlayersList').addEventListener('click', event => {
    const button = event.target.closest('[data-remove-invite]');
    if (!button) return;
    const world = getAccessWorld();
    const row = button.closest('[data-invite-user]');
    if (!world || !row) return;
    const removed = world.invites.find(item => item.username.toLowerCase() === row.dataset.inviteUser);
    world.invites = world.invites.filter(item => item.username.toLowerCase() !== row.dataset.inviteUser);
    saveProfile(); syncWorldInvites(world); renderInvitedPlayers();
    $('#invitePlayerMessage').textContent = `${removed?.username || 'Player'} was removed from this world.`;
  });
  $('#publishedGamesGrid').addEventListener('click', event => {
    const createButton = event.target.closest('[data-create-room]');
    if (createButton) { enterPublicRoom(createButton.dataset.createRoom, 'create'); return; }
    const publicButton = event.target.closest('[data-join-public]');
    if (publicButton) { enterPublicRoom(publicButton.dataset.joinPublic, 'join'); return; }
    const roomButton = event.target.closest('[data-join-room]');
    if (roomButton) { enterPublicRoom(roomButton.dataset.roomWorld, 'join', roomButton.dataset.joinRoom); return; }
    const playButton = event.target.closest('[data-published-world-id]');
    if (playButton) enterPublicRoom(playButton.dataset.publishedWorldId, 'join');
  });
  function closePublishWorldPrompt() { pendingPublishWorldId = null; publishWorldModal.classList.remove('show'); }
  $$('[data-cancel-world-publish]').forEach(button => button.addEventListener('click', closePublishWorldPrompt));
  publishWorldModal.addEventListener('click', event => { if (event.target === publishWorldModal) closePublishWorldPrompt(); });
  $('#confirmPublishWorld').addEventListener('click', async () => {
    if (!pendingPublishWorldId) return;
    const world = profile.worlds.find(item => item.id === pendingPublishWorldId);
    if (!world) { closePublishWorldPrompt(); return; }
    world.published = true;
    world.publishedAt = new Date().toISOString();
    world.publishVersion = (world.publishVersion || 0) + 1;
    const existingPublished = readPublishedGames().find(game => game.id === world.id);
    const published = readPublishedGames().filter(game => game.id !== world.id);
    const liveWorld = { ...world, owner:profile.name, plays:existingPublished?.plays || 0 };
    published.unshift(liveWorld);
    writePublishedGames(published);
    saveProfile();
    try {
      await publishWorldToServer(liveWorld);
      showToast('World published!', 'Players on every device can now join');
      await syncPublicWorldsFromServer();
    } catch (error) {
      showToast('Saved on this device', error.message || 'Public server will retry soon');
    }
    closePublishWorldPrompt(); beep(1040, .18);
  });
  function closeDeleteWorldPrompt() { pendingDeleteWorldId = null; deleteWorldModal.classList.remove('show'); }
  $$('[data-cancel-world-delete]').forEach(button => button.addEventListener('click', closeDeleteWorldPrompt));
  deleteWorldModal.addEventListener('click', event => { if (event.target === deleteWorldModal) closeDeleteWorldPrompt(); });
  $('#confirmDeleteWorld').addEventListener('click', () => {
    if (!pendingDeleteWorldId) return;
    const deletedWorldId = pendingDeleteWorldId;
    if (!profile.deletedWorldIds.includes(pendingDeleteWorldId)) profile.deletedWorldIds.push(pendingDeleteWorldId);
    profile.worlds = profile.worlds.filter(world => world.id !== pendingDeleteWorldId);
    writePublishedGames(readPublishedGames().filter(world => world.id !== pendingDeleteWorldId));
    deleteWorldFromServer(deletedWorldId).catch(() => {});
    saveProfile(); closeDeleteWorldPrompt(); beep(320, .12);
  });

  const addFriendModal = $('#addFriendModal');
  const unfriendModal = $('#unfriendModal');
  const multiplayerSetupModal = $('#multiplayerSetupModal');
  let pendingUnfriendId = null;
  function openMultiplayerSetup(friendName = '') {
    const copy = $('#multiplayerSetupCopy');
    copy.textContent = friendName
      ? `${friendName} can join you by opening the same published world and choosing your public room code.`
      : 'Open Published Games and choose Create Room or Join Public. Everyone who joins the same room appears inside that world.';
    multiplayerSetupModal.classList.add('show');
    beep(720, .12);
  }
  function closeMultiplayerSetup() { multiplayerSetupModal.classList.remove('show'); }
  $('#playTogetherBtn').addEventListener('click', () => openMultiplayerSetup());
  $$('[data-close-multiplayer]').forEach(button => button.addEventListener('click', closeMultiplayerSetup));
  $('.multiplayer-ok').addEventListener('click', () => switchView('discover'));
  multiplayerSetupModal.addEventListener('click', event => { if (event.target === multiplayerSetupModal) closeMultiplayerSetup(); });
  function closeFriendFinder() {
    addFriendModal.classList.remove('show');
    $('#friendUsernameInput').value = '';
    $('#friendAddMessage').textContent = '';
  }
  $('#addFriendBtn').addEventListener('click', () => {
    addFriendModal.classList.add('show');
    $('#friendUsernameInput').focus();
    beep(700);
  });
  $$('[data-close-friends]').forEach(button => button.addEventListener('click', closeFriendFinder));
  addFriendModal.addEventListener('click', event => { if (event.target === addFriendModal) closeFriendFinder(); });
  $('#addFriendForm').addEventListener('submit', event => {
    event.preventDefault();
    const input = $('#friendUsernameInput');
    const username = input.value.trim();
    const message = $('#friendAddMessage');
    message.classList.remove('success');
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) { message.textContent = 'Enter a valid username with 3–16 characters.'; return; }
    if (username.toLowerCase() === profile.name.toLowerCase()) { message.textContent = 'You cannot add your own account.'; return; }
    if (profile.friends.some(friend => friend.name.toLowerCase() === username.toLowerCase())) { message.textContent = `${username} is already your friend.`; return; }
    const colors = ['pink','blue','green','amber','violet'];
    const colorIndex = [...username].reduce((total, letter) => total + letter.charCodeAt(0), 0) % colors.length;
    profile.friends.push({ id: username.toLowerCase(), name: username, color: colors[colorIndex] });
    saveProfile();
    message.textContent = `${username} was added to your friends!`;
    message.classList.add('success');
    input.value = '';
    beep(880, .12);
  });
  $('#friendList').addEventListener('click', event => {
    const button = event.target.closest('[data-friend-action]');
    if (!button) return;
    const card = button.closest('[data-friend-id]');
    const friendId = card.dataset.friendId;
    const friend = profile.friends.find(item => (item.id || item.name.toLowerCase()) === friendId);
    if (button.dataset.friendAction === 'play-together') {
      openMultiplayerSetup(friend?.name || 'This friend');
      return;
    }
    if (button.dataset.friendAction !== 'unfriend') return;
    pendingUnfriendId = friendId;
    $('#unfriendPlayerName').textContent = friend ? friend.name : 'This player';
    unfriendModal.classList.add('show');
  });
  function closeUnfriendPrompt() { pendingUnfriendId = null; unfriendModal.classList.remove('show'); }
  $$('[data-cancel-unfriend]').forEach(button => button.addEventListener('click', closeUnfriendPrompt));
  unfriendModal.addEventListener('click', event => { if (event.target === unfriendModal) closeUnfriendPrompt(); });
  $('#confirmUnfriend').addEventListener('click', () => {
    if (!pendingUnfriendId) return;
    profile.friends = profile.friends.filter(friend => (friend.id || friend.name.toLowerCase()) !== pendingUnfriendId);
    saveProfile(); closeUnfriendPrompt(); beep(360, .1);
  });

  const settingsModal = $('#settingsModal');
  const accountSwitcherModal = $('#accountSwitcherModal');
  function renderSavedAccounts() {
    const current = sessionMode === 'account' ? readSavedAccount()?.username?.toLowerCase() : null;
    const accounts = savedAccountList().sort((a, b) => (a.username.toLowerCase() === current ? -1 : b.username.toLowerCase() === current ? 1 : a.username.localeCompare(b.username)));
    const list = $('#savedAccountsList');
    if (!accounts.length) { list.innerHTML = '<div class="account-switch-empty">No saved accounts yet.</div>'; return; }
    list.innerHTML = accounts.map(account => {
      const isCurrent = account.username.toLowerCase() === current;
      const worldCount = Array.isArray(account.profile.worlds) ? account.profile.worlds.length : 0;
      return `<button class="saved-account-row ${isCurrent ? 'current' : ''}" data-switch-account="${account.username.toLowerCase()}" ${isCurrent ? 'disabled' : ''}><span class="saved-account-avatar">${escapeHTML(account.username.charAt(0).toUpperCase())}</span><span><b>${escapeHTML(account.username)}</b><small>Level ${account.profile.level || 1} • ${worldCount} world${worldCount === 1 ? '' : 's'}</small></span><em>${isCurrent ? 'CURRENT' : 'SWITCH'}</em></button>`;
    }).join('');
  }
  function showAccountScreen(mode = 'signin', username = '') {
    if (game.active) leaveGame();
    settingsModal.classList.remove('show');
    accountSwitcherModal.classList.remove('show');
    sessionMode = 'signed-out'; profile = defaultProfile(); updateProfileUI(); syncCustomizer();
    $('#appShell').setAttribute('inert', '');
    accountScreen.classList.remove('hidden');
    $('#createUsername').value = '';
    $('#createBirthdate').value = '';
    $('#confirmAge').checked = false;
    $('#signInUsername').value = username;
    updateSavedAccountHint();
    selectAuthTab(mode);
  }
  $('#settingsBtn').addEventListener('click', () => settingsModal.classList.add('show'));
  $$('[data-close]').forEach(button => button.addEventListener('click', () => settingsModal.classList.remove('show')));
  settingsModal.addEventListener('click', e => { if (e.target === settingsModal) settingsModal.classList.remove('show'); });
  function openAccountSwitcher() {
    settingsModal.classList.remove('show');
    renderSavedAccounts();
    accountSwitcherModal.classList.add('show');
  }
  $('#switchAccountButton').addEventListener('click', openAccountSwitcher);
  $('#homeSwitchAccountButton').addEventListener('click', openAccountSwitcher);
  $$('[data-close-account-switch]').forEach(button => button.addEventListener('click', () => accountSwitcherModal.classList.remove('show')));
  accountSwitcherModal.addEventListener('click', event => { if (event.target === accountSwitcherModal) accountSwitcherModal.classList.remove('show'); });
  $('#savedAccountsList').addEventListener('click', event => {
    const button = event.target.closest('[data-switch-account]');
    if (!button || button.disabled) return;
    const account = readAccounts()[button.dataset.switchAccount];
    if (!account) { renderSavedAccounts(); return; }
    if (!account.profile?.ageVerified) { showAccountScreen('signin', account.username); return; }
    if (game.active) leaveGame();
    accountSwitcherModal.classList.remove('show');
    rememberAccount(account);
    enterSession(account.profile, 'account');
    showToast('Account switched', `Now playing as ${account.username}`);
  });
  $('#addAnotherAccount').addEventListener('click', () => showAccountScreen('create'));
  $('#signOutButton').addEventListener('click', () => {
    const saved = readSavedAccount();
    showAccountScreen('signin', saved?.username || '');
  });
  const worlds = {};

  const canvas = $('#gameCanvas');
  const ctx = canvas.getContext('2d');
  const brainrotCatalog = [
    { name:'Noobini Nugget', tag:'NN', color:'#ffcf5a', accent:'#ff7a90', value:1 },
    { name:'Cappuccino Cat', tag:'CC', color:'#c7955c', accent:'#54edff', value:2 },
    { name:'Pixel Goblin', tag:'PG', color:'#55e082', accent:'#7557ff', value:3 },
    { name:'Baller Banana', tag:'BB', color:'#ffe65c', accent:'#ff9f43', value:4 },
    { name:'Sigma Cube', tag:'SC', color:'#9b7cff', accent:'#34e1a1', value:5 }
  ];
  const game = {
    active: false, paused: false, world: null, worldRecord: null, userWorldId: null, publishedWorldId: null, canBuild: false, isWorldOwner: false, loadedBlocks: null, worldSize: 12, last: 0, time: 0, keys: {}, buildMode: false, selectedBlock: 1, boosts: { speed:0, jump:0, magnet:0 },
    player: { x: 5, y: 5, z: 0, vz: 0, angle: 0 }, camera: { x: 0, y: 0 }, collected: 0,
    coins: [], blocks: [], particles: [], pet: { x: 4.3, y: 5.5, z: 0 }, npc: { x: 7.5, y: 5.5, name: 'Nova' },
    brainrotMode: false, brainrotBase: null, brainrotEnemyBase: null, brainrots: [], carriedBrainrot: null, brainrotScore: 0, brainrotWave: 1, brainrotSpawnCooldown: 0,
    look: { yaw:0, pitch:0, locked:false, dragging:false, pointerId:null, lastX:0, lastY:0, sensitivity:.0032 }
  };

  const tileW = 72, tileH = 36, blockH = 33;
  const rand = (min, max) => min + Math.random() * (max - min);
  const shade = (hex, amount) => {
    const n = parseInt(hex.slice(1), 16), r = Math.max(0, Math.min(255, (n >> 16) + amount)), g = Math.max(0, Math.min(255, ((n >> 8) & 255) + amount)), b = Math.max(0, Math.min(255, (n & 255) + amount));
    return `rgb(${r},${g},${b})`;
  };
  function project(x, y, z = 0) {
    return { x: canvas.width / 2 + (x - y) * tileW / 2 - game.camera.x, y: canvas.height * .37 + (x + y) * tileH / 2 - z * blockH - game.camera.y };
  }
  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }
  function resetMouseLook() {
    game.look.yaw = 0;
    game.look.pitch = 0;
    game.look.locked = false;
    game.look.dragging = false;
    game.look.pointerId = null;
    game.look.lastX = 0;
    game.look.lastY = 0;
  }
  function applyMouseLook(deltaX, deltaY) {
    if (!game.active || !game.brainrotMode || game.paused) return;
    game.look.yaw += deltaX * game.look.sensitivity;
    game.look.pitch = clamp(game.look.pitch + deltaY * game.look.sensitivity, -.55, .65);
  }
  function requestMouseLook() {
    if (!game.active || !game.brainrotMode || game.paused) return;
    if (canvas.requestPointerLock && document.pointerLockElement !== canvas) {
      const lockRequest = canvas.requestPointerLock();
      lockRequest?.catch?.(() => showToast('Mouse look ready', 'Drag on the game to look around'));
      showToast('Mouse look on', 'Move mouse to look around • Esc releases');
      return;
    }
    showToast('Mouse look ready', 'Drag on the game to look around');
  }
  function stopMouseLook() {
    game.look.dragging = false;
    game.look.pointerId = null;
    if (document.pointerLockElement === canvas && document.exitPointerLock) document.exitPointerLock();
  }
  document.addEventListener('pointerlockchange', () => {
    game.look.locked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', event => {
    if (game.look.locked) applyMouseLook(event.movementX || 0, event.movementY || 0);
  });

  function resize() {
    canvas.width = innerWidth; canvas.height = innerHeight;
    canvas.style.width = innerWidth + 'px'; canvas.style.height = innerHeight + 'px';
  }
  window.addEventListener('resize', resize); resize();

  function isBrainrotWorldRecord(record) {
    if (!record) return false;
    const text = `${record.name || ''} ${record.description || ''}`.toLowerCase();
    return !!record.brainrotMode || !!record.baseGame || text.includes('brainrot');
  }
  function clampWorld(value, min = .25, max = game.worldSize - .25) {
    return Math.max(min, Math.min(max, value));
  }
  function brainrotBaseForWorld(size) {
    const baseSize = Math.min(5, Math.max(4, Math.floor(size / 5)));
    const centeredX = Math.max(1, Math.floor(size / 2 - baseSize / 2));
    return {
      home: { x:centeredX, y:Math.max(1, size - baseSize - 1), w:baseSize, h:baseSize, label:'YOUR BASE', color:'#34e1a1' },
      enemy: { x:centeredX, y:1, w:baseSize, h:baseSize, label:'BRAINROT DEN', color:'#ff5fd2' }
    };
  }
  function resetPlayerToSpawn() {
    if (game.brainrotMode && game.brainrotBase) {
      game.player = { x:game.brainrotBase.x + game.brainrotBase.w / 2, y:game.brainrotBase.y + game.brainrotBase.h / 2, z:0, vz:0, angle:0 };
      game.pet = { x:clampWorld(game.player.x - .7), y:clampWorld(game.player.y + .5), z:0 };
      return;
    }
    game.player = { x:5, y:5, z:0, vz:0, angle:0 };
    game.pet = { x:4.3, y:5.5, z:0 };
  }
  function sourceBrainrotsForWorld(record) {
    const custom = Array.isArray(record?.brainrots) ? record.brainrots.filter(item => item && item.name) : [];
    return custom.length ? custom : brainrotCatalog;
  }
  function spawnBrainrotWave(record = game.worldRecord) {
    const source = sourceBrainrotsForWorld(record);
    const count = Math.min(5, Math.max(3, source.length || 3));
    const size = game.worldSize;
    const center = (size - 1) / 2;
    const startY = Math.min(size - 3, Math.max(2, (game.brainrotEnemyBase?.y || 1) + (game.brainrotEnemyBase?.h || 4) + 1));
    const endY = Math.max(startY, Math.min(size - 3, (game.brainrotBase?.y || size - 5) - 2));
    game.brainrots = Array.from({ length:count }, (_, index) => {
      const item = source[index % source.length] || brainrotCatalog[index % brainrotCatalog.length];
      const fallbackX = center + ((index % 3) - 1) * 1.25;
      const fallbackY = count === 1 ? (startY + endY) / 2 : startY + (endY - startY) * (index / Math.max(1, count - 1));
      const x = Number.isFinite(Number(item.x)) ? Number(item.x) : fallbackX;
      const y = Number.isFinite(Number(item.y)) ? Number(item.y) : fallbackY;
      return {
        id:`brainrot-${game.brainrotWave}-${index}`,
        name:String(item.name || brainrotCatalog[index % brainrotCatalog.length].name).slice(0, 24),
        tag:String(item.tag || item.name || 'BR').replace(/[^A-Za-z0-9]/g, '').slice(0, 2).toUpperCase() || 'BR',
        color:item.color || brainrotCatalog[index % brainrotCatalog.length].color,
        accent:item.accent || brainrotCatalog[index % brainrotCatalog.length].accent,
        value:Math.max(1, Math.min(10, Math.floor(Number(item.value) || (index + 1)))),
        x:clampWorld(x), y:clampWorld(y), z:0, carried:false, delivered:false, phase:index * .9
      };
    });
    game.brainrotWave += 1;
  }
  function setupBrainrotMode(record) {
    if (!game.brainrotMode) { updateBrainrotHud(); return; }
    const zones = brainrotBaseForWorld(game.worldSize);
    game.brainrotBase = zones.home;
    game.brainrotEnemyBase = zones.enemy;
    game.carriedBrainrot = null;
    game.brainrotSpawnCooldown = 0;
    game.brainrotWave = 1;
    game.brainrotScore = game.userWorldId ? Math.max(0, Math.floor(Number(record?.brainrotScore) || 0)) : 0;
    resetMouseLook();
    resetPlayerToSpawn();
    spawnBrainrotWave(record);
    $('#questTitle').textContent = 'Brainrot Base Run';
    $('#questText').textContent = 'Grab a brainrot and bring it to YOUR BASE';
    updateBrainrotHud();
  }
  function generateWorld() {
    game.player = { x: 5, y: 5, z: 0, vz: 0, angle: 0 }; game.camera = { x: 0, y: 0 }; game.pet = { x: 4.3, y: 5.5, z: 0 }; game.collected = 0; game.coins = []; game.blocks = []; game.particles = []; game.boosts = { speed:0, jump:0, magnet:0 }; game.brainrotBase = null; game.brainrotEnemyBase = null; game.brainrots = []; game.carriedBrainrot = null; game.brainrotSpawnCooldown = 0;
    const fixed = [[2,2,2,2],[2,3,2,2],[3,2,1,3],[8,3,1,2],[9,3,2,2],[8,4,1,2],[3,8,1,1],[7,8,2,3],[8,8,1,3],[10,7,1,2],[1,7,1,1]];
    if (Array.isArray(game.loadedBlocks)) game.blocks = game.loadedBlocks.map(block => ({ ...block }));
    else fixed.forEach(([x,y,h,type]) => game.blocks.push({ x,y,h,type }));
    [[3.5,5.5],[6.5,2.6],[9.3,6.1],[4.2,9.1],[8.3,9.5],[1.8,3.8],[10.2,3.1],[6.1,8.1]].forEach(([x,y], index) => game.coins.push({ x,y,z:.45,got:false,phase:index }));
    setupBrainrotMode(game.worldRecord);
    updateQuest();
  }

  function launchGame(key, publishedLaunch = false) {
    const ownedWorld = profile.worlds.find(world => world.id === key);
    const publishedGames = readPublishedGames();
    const publishedWorld = publishedGames.find(world => world.id === key);
    const worldRecord = publishedLaunch ? publishedWorld : ownedWorld;
    const recordAccess = worldRecord || {};
    const selectedWorld = worldRecord ? worldConfigFromRecord(worldRecord) : worlds[key];
    if (!selectedWorld) return;
    const signedInPlayer = sessionMode === 'account';
    const isWorldOwner = (!!ownedWorld && !publishedLaunch) || (signedInPlayer && String(recordAccess.owner || '').toLowerCase() === profile.name.toLowerCase());
    const invite = (Array.isArray(recordAccess.invites) ? recordAccess.invites : []).find(item => String(item.username || '').toLowerCase() === profile.name.toLowerCase());
    game.world = selectedWorld; game.worldRecord = recordAccess; game.userWorldId = !publishedLaunch && ownedWorld ? ownedWorld.id : null; game.publishedWorldId = publishedLaunch && publishedWorld ? publishedWorld.id : null; game.isWorldOwner = isWorldOwner; game.canBuild = isWorldOwner || signedInPlayer && !!invite?.canBuild; game.loadedBlocks = Array.isArray(recordAccess.blocks) ? recordAccess.blocks.map(block => ({ ...block })) : null; game.worldSize = cleanWorldSize(recordAccess.size); game.brainrotMode = isBrainrotWorldRecord(worldRecord || selectedWorld); game.active = true; game.paused = false; game.buildMode = false; game.time = 0;
    if (publishedLaunch && publishedWorld) { publishedWorld.plays = (publishedWorld.plays || 0) + 1; writePublishedGames(publishedGames); renderPublishedGames(); if (publicWorldApi) fetch(publicWorldApi,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'play',worldId:publishedWorld.id})}).catch(()=>{}); }
    else if (ownedWorld) { ownedWorld.visits = (ownedWorld.visits || 0) + 1; saveProfile(); }
    $('#worldName').textContent = game.world.name; $('#worldIcon').textContent = game.world.icon; $('#serverName').textContent = game.canBuild ? (game.isWorldOwner ? 'Owner build access' : 'Builder permission granted') : 'Play-only access';
    $('#questTitle').textContent = game.world.quest; $('#questText').textContent = game.world.text;
    $('#gameScreen').classList.add('active'); $('#pausePanel').classList.remove('show'); $('#buildToolbar').classList.remove('show'); $('#mobileBuild').classList.remove('active'); $('#mobileBuild').classList.toggle('locked', !game.canBuild); $('#mobileBuild').textContent = game.canBuild ? 'BUILD' : 'VIEW';
    document.body.style.overflow = 'hidden'; generateWorld(); resize(); beep(330, .08); setTimeout(() => beep(660, .12), 100);
    game.last = performance.now(); requestAnimationFrame(loop);
  }
  $$('[data-game]').forEach(button => button.addEventListener('click', event => { event.stopPropagation(); launchGame(button.dataset.game); }));
  $$('.game-card').forEach(card => card.addEventListener('dblclick', () => launchGame($('.card-play', card).dataset.game)));

  function leaveGame() {
    stopMouseLook(); leavePublicRoom(); game.active = false; game.paused = false; game.brainrotMode = false; updateBrainrotHud(); $('#gameScreen').classList.remove('active'); $('#gameShopModal').classList.remove('show'); $('#robuxMachineModal').classList.remove('show'); document.body.style.overflow = ''; refreshPublicRoomCards(); beep(280, .08);
  }
  function togglePause(force) {
    game.paused = typeof force === 'boolean' ? force : !game.paused;
    if (game.paused) stopMouseLook();
    $('#pausePanel').classList.toggle('show', game.paused);
  }
  $('#exitGame').addEventListener('click', () => togglePause());
  $('#resumeGame').addEventListener('click', () => togglePause(false));
  $('#leaveGame').addEventListener('click', leaveGame);
  $('#resetPlayer').addEventListener('click', () => { dropCarriedBrainrot(); resetPlayerToSpawn(); togglePause(false); showToast('Character reset', game.brainrotMode ? 'Back at your base' : 'Back at spawn'); });

  function openGameShop() {
    if (!game.active) return;
    game.paused = true;
    $('#pausePanel').classList.remove('show');
    renderPets();
    renderShopItems();
    $('#gameShopItemMessage').textContent = '';
    $('#gameShopModal').classList.add('show');
    beep(760, .08);
  }
  function closeGameShop() {
    $('#gameShopModal').classList.remove('show');
    if (game.active) game.paused = false;
  }
  $('#gameShopButton').addEventListener('click', openGameShop);
  $('#closeGameShop').addEventListener('click', closeGameShop);
  $('#gameShopModal').addEventListener('click', event => { if (event.target === $('#gameShopModal')) closeGameShop(); });

  function renderRobuxMachineShop() {
    const grid = $('#machineShopGrid');
    if (!grid) return;
    $('#machineCoins').textContent = profile.coins;
    grid.innerHTML = machineShopCatalog.map(item => {
      const owned = item.kind === 'item' && profile.machineItems.includes(item.id);
      const boostTime = item.effect ? Math.ceil(game.boosts[item.effect] || 0) : 0;
      const label = owned ? 'OWNED' : boostTime > 0 ? `${boostTime}s LEFT` : `BUY FOR R ${item.price}`;
      return `<button class="machine-shop-card ${owned || boostTime > 0 ? 'owned' : ''}" type="button" data-machine-item="${item.id}" ${owned ? 'disabled' : ''}><span>${item.kind === 'boost' ? '⚡' : '✦'}</span><b>${escapeHTML(item.name)}</b><small>${escapeHTML(item.description)}</small><em>${label}</em></button>`;
    }).join('');
  }
  function openRobuxMachineShop() {
    if (!game.active) return;
    game.paused = true;
    $('#pausePanel').classList.remove('show');
    $('#machineShopMessage').textContent = '';
    renderRobuxMachineShop();
    $('#robuxMachineModal').classList.add('show');
    beep(860, .09);
  }
  function closeRobuxMachineShop() {
    $('#robuxMachineModal').classList.remove('show');
    if (game.active) game.paused = false;
  }
  function buyMachineItem(itemId) {
    const item = machineShopCatalog.find(entry => entry.id === itemId);
    if (!item) return;
    if (item.kind === 'item' && profile.machineItems.includes(item.id)) return;
    if (profile.coins < item.price) {
      $('#machineShopMessage').textContent = `You need R ${formatRobux(item.price - profile.coins)} more Robux for ${item.name}.`;
      showToast('Not enough Robux', `Need R ${formatRobux(item.price)}`);
      beep(240, .12);
      return;
    }
    profile.coins -= item.price;
    if (item.kind === 'boost') game.boosts[item.effect] = Math.max(game.boosts[item.effect] || 0, item.duration);
    else profile.machineItems.push(item.id);
    saveProfile();
    renderRobuxMachineShop();
    $('#machineShopMessage').textContent = `${item.name} bought for R ${formatRobux(item.price)}.`;
    showToast(`${item.name} bought!`, item.kind === 'boost' ? 'Boost active in this world' : 'Saved to your profile');
    spawnParticles(game.player.x, game.player.y, game.player.z + .5, '#ffd35a', 24);
    beep(1120, .18);
  }
  $('#closeRobuxMachine').addEventListener('click', closeRobuxMachineShop);
  $('#robuxMachineModal').addEventListener('click', event => { if (event.target === $('#robuxMachineModal')) closeRobuxMachineShop(); });
  $('#machineShopGrid').addEventListener('click', event => {
    const button = event.target.closest('[data-machine-item]');
    if (button && !button.disabled) buyMachineItem(button.dataset.machineItem);
  });

  function setBuildMode(enabled) {
    if (enabled && !game.canBuild) { showToast('Build permission required', 'The world owner has not allowed you to build'); beep(260, .1); return; }
    if (enabled) stopMouseLook();
    game.buildMode = enabled;
    $('#buildToolbar').classList.toggle('show', enabled);
    $('#mobileBuild').classList.toggle('active', enabled);
    beep(enabled ? 700 : 420);
  }

  window.addEventListener('keydown', event => {
    if (!game.active) return;
    if (['input','textarea','select'].includes(document.activeElement?.tagName?.toLowerCase())) return;
    const key = event.key.toLowerCase(); game.keys[key] = true;
    if ([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(key)) event.preventDefault();
    if (key === 'escape') { const hadLook = game.look.locked || game.look.dragging; stopMouseLook(); if (hadLook) return; if ($('#robuxMachineModal').classList.contains('show')) closeRobuxMachineShop(); else if ($('#gameShopModal').classList.contains('show')) closeGameShop(); else togglePause(); }
    if (key === 'b' && !event.repeat) setBuildMode(!game.buildMode);
    if (key === 'e' && !event.repeat) { if (nearRobuxMachine()) openRobuxMachineShop(); else openGameShop(); }
    if (key === 'f' && nearNpc()) { showToast('Nova says hello!', 'Keep exploring, Builder!'); game.npc.talk = 2; }
  });
  window.addEventListener('keyup', event => { game.keys[event.key.toLowerCase()] = false; });
  $$('.mobile-controls button[data-key]').forEach(button => {
    const key = button.dataset.key;
    button.addEventListener('pointerdown', e => { e.preventDefault(); game.keys[key] = true; });
    button.addEventListener('pointerup', () => game.keys[key] = false);
    button.addEventListener('pointercancel', () => game.keys[key] = false);
  });
  $('#mobileBuild').addEventListener('click', () => setBuildMode(!game.buildMode));
  $('#mobileShopButton').addEventListener('click', openGameShop);
  $('#mobileInteract').addEventListener('click', () => {
    if (nearRobuxMachine()) { openRobuxMachineShop(); }
    else if (nearNpc()) { showToast('Nova says hello!', 'Keep exploring, Builder!'); game.npc.talk = 2; beep(620); }
    else showToast('Nobody nearby', 'Move closer to another player');
  });
  $$('#buildToolbar button[data-block]').forEach(button => button.addEventListener('click', () => { $$('#buildToolbar button[data-block]').forEach(b => b.classList.toggle('active', b === button)); game.selectedBlock = +button.dataset.block; beep(620); }));
  $('#expandPlatform').addEventListener('click', () => {
    if (!game.active || !game.userWorldId) { showToast('Draft worlds only', 'Open your own world to expand it'); return; }
    const growBy = Math.max(4, Math.min(24, Math.ceil(game.worldSize / 6)));
    game.worldSize = cleanWorldSize(game.worldSize + growBy);
    const record = profile.worlds.find(world => world.id === game.userWorldId);
    if (record) { record.size = game.worldSize; saveProfile(); }
    showToast('Platform expanded!', `${game.worldSize} × ${game.worldSize} tiles`);
    beep(820, .12);
  });

  function screenToTile(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    if (game.brainrotMode) {
      const sx = clientX - rect.left;
      const sy = clientY - rect.top;
      const horizon = canvas.clientHeight * (.17 - game.look.pitch * .16);
      const bottom = canvas.clientHeight * (.91 - game.look.pitch * .1);
      const rawScale = (sy - horizon) / Math.max(1, bottom - horizon);
      const scale = Math.max(.08, Math.min(1.25, rawScale));
      const forwardDistance = 1 / scale;
      const lane = Math.min(220, Math.max(115, canvas.clientWidth * .24));
      const side = (sx - canvas.clientWidth / 2) / Math.max(1, lane * scale);
      const camera = brainrotCameraBasis();
      return {
        x:Math.round(camera.x + camera.forward.x * forwardDistance + camera.right.x * side),
        y:Math.round(camera.y + camera.forward.y * forwardDistance + camera.right.y * side)
      };
    }
    const sx = clientX - rect.left - canvas.clientWidth/2 + game.camera.x;
    const sy = clientY - rect.top - canvas.clientHeight*.37 + game.camera.y;
    return { x: Math.round(sy/tileH + sx/tileW), y: Math.round(sy/tileH - sx/tileW) };
  }
  function saveWorldBlocks() {
    const savedBlocks = game.blocks.map(block => ({ x:block.x, y:block.y, h:block.h, type:block.type }));
    if (game.userWorldId) {
      const record = profile.worlds.find(world => world.id === game.userWorldId);
      if (!record) return;
      record.blocks = savedBlocks;
      saveProfile();
      return;
    }
    if (game.publishedWorldId && game.canBuild) {
      const published = readPublishedGames();
      const liveWorld = published.find(world => world.id === game.publishedWorldId);
      if (!liveWorld) return;
      liveWorld.blocks = savedBlocks;
      liveWorld.lastBuiltBy = profile.name;
      liveWorld.updatedAt = new Date().toISOString();
      writePublishedGames(published);
    }
  }
  canvas.addEventListener('contextmenu', event => event.preventDefault());
  canvas.addEventListener('pointerdown', event => {
    if (game.brainrotMode && !game.paused && !game.buildMode) {
      event.preventDefault();
      if (event.pointerType === 'mouse') requestMouseLook();
      else {
        game.look.dragging = true;
        game.look.pointerId = event.pointerId;
        game.look.lastX = event.clientX;
        game.look.lastY = event.clientY;
        canvas.setPointerCapture?.(event.pointerId);
        showToast('Touch look on', 'Drag to look around');
      }
      return;
    }
    if (!game.buildMode || game.paused || !game.canBuild) return;
    const tile = screenToTile(event.clientX, event.clientY);
    if (tile.x < 0 || tile.y < 0 || tile.x >= game.worldSize || tile.y >= game.worldSize) return;
    const index = game.blocks.findIndex(block => block.x === tile.x && block.y === tile.y);
    const removing = event.pointerType === 'mouse' ? event.button === 0 : game.selectedBlock === 0;
    const placementType = game.selectedBlock === 0 ? 1 : game.selectedBlock;
    if (removing) { if (index >= 0) game.blocks.splice(index, 1); }
    else if (index >= 0 && placementType === 4) game.blocks[index] = { x: tile.x, y: tile.y, h: 1, type: 4 };
    else if (index >= 0 && game.blocks[index].type === 4) game.blocks[index] = { x: tile.x, y: tile.y, h: 1, type: placementType };
    else if (index >= 0) game.blocks[index].h = Math.min(4, game.blocks[index].h + 1);
    else game.blocks.push({ x: tile.x, y: tile.y, h: 1, type: placementType });
    saveWorldBlocks();
    spawnParticles(tile.x + .5, tile.y + .5, .4, game.world.accent, 10); beep(removing ? 300 : 540);
  });
  canvas.addEventListener('pointermove', event => {
    if (!game.look.dragging || game.look.pointerId !== event.pointerId) return;
    event.preventDefault();
    applyMouseLook(event.clientX - game.look.lastX, event.clientY - game.look.lastY);
    game.look.lastX = event.clientX;
    game.look.lastY = event.clientY;
  });
  ['pointerup','pointercancel','lostpointercapture'].forEach(type => canvas.addEventListener(type, event => {
    if (game.look.pointerId === event.pointerId || type === 'lostpointercapture') {
      game.look.dragging = false;
      game.look.pointerId = null;
    }
  }));

  function highestBlockAt(x, y) {
    const tx = Math.floor(x), ty = Math.floor(y), block = game.blocks.find(item => item.x === tx && item.y === ty);
    return block ? block.h : 0;
  }
  function nearRobuxMachine() {
    return game.blocks.find(block => block.type === 4 && Math.hypot(game.player.x - (block.x + .5), game.player.y - (block.y + .5)) < 1.35);
  }
  function nearNpc() { return Math.hypot(game.player.x - game.npc.x, game.player.y - game.npc.y) < 1.45; }
  function updateInteractPrompt() {
    const prompt = $('#interactPrompt');
    const machine = nearRobuxMachine();
    const nova = nearNpc();
    if (machine || nova) {
      $('kbd', prompt).textContent = machine ? 'E' : 'F';
      $('span', prompt).textContent = machine ? 'Use Robux Machine' : 'Talk to Nova';
      prompt.classList.add('show');
      $('#mobileInteract').textContent = machine ? 'MACHINE' : 'TALK';
      return;
    }
    prompt.classList.remove('show');
    $('#mobileInteract').textContent = 'USE';
  }

  function pointInBase(point, zone) {
    return !!zone && point.x >= zone.x && point.x <= zone.x + zone.w && point.y >= zone.y && point.y <= zone.y + zone.h;
  }
  function carriedBrainrot() {
    return game.brainrots.find(item => item.id === game.carriedBrainrot);
  }
  function dropCarriedBrainrot() {
    const brainrot = carriedBrainrot();
    if (brainrot && !brainrot.delivered) {
      brainrot.carried = false;
      brainrot.x = clampWorld(game.player.x + .65);
      brainrot.y = clampWorld(game.player.y + .65);
      brainrot.z = highestBlockAt(brainrot.x, brainrot.y);
    }
    game.carriedBrainrot = null;
    updateBrainrotHud();
  }
  function saveBrainrotProgress() {
    if (!game.userWorldId) return;
    const record = profile.worlds.find(world => world.id === game.userWorldId);
    if (!record) return;
    record.brainrotMode = true;
    record.baseGame = true;
    record.brainrotScore = game.brainrotScore;
  }
  function pickUpBrainrot(brainrot) {
    if (!brainrot || brainrot.delivered || game.carriedBrainrot) return;
    brainrot.carried = true;
    game.carriedBrainrot = brainrot.id;
    spawnParticles(brainrot.x, brainrot.y, .6, brainrot.accent || game.world.accent, 18);
    showToast(`Got ${brainrot.name}!`, 'Bring it back to YOUR BASE');
    beep(980, .12, .035);
    updateBrainrotHud();
  }
  function deliverBrainrot(brainrot) {
    if (!brainrot || brainrot.delivered) return;
    brainrot.delivered = true;
    brainrot.carried = false;
    game.carriedBrainrot = null;
    game.brainrotScore += 1;
    const reward = Math.max(10, brainrot.value * 25);
    profile.coins += reward;
    profile.xp = Math.min(500, profile.xp + 20 + brainrot.value * 4);
    saveBrainrotProgress();
    saveProfile(`Stored ${brainrot.name} in your Brainrot base`);
    spawnParticles(game.player.x, game.player.y, game.player.z + .7, brainrot.accent || '#34e1a1', 32);
    showToast(`${brainrot.name} stored!`, `+${reward} R for your base`);
    beep(1180, .2, .04);
    if (game.brainrots.every(item => item.delivered)) game.brainrotSpawnCooldown = 1.5;
    updateBrainrotHud();
    updateQuest();
  }
  function updateBrainrotMode(dt) {
    if (!game.brainrotMode) return;
    if (game.brainrotSpawnCooldown > 0) {
      game.brainrotSpawnCooldown = Math.max(0, game.brainrotSpawnCooldown - dt);
      if (game.brainrotSpawnCooldown === 0) {
        spawnBrainrotWave(game.worldRecord);
        showToast('New brainrots spawned!', 'Go steal another one');
      }
    }
    const p = game.player;
    const carried = carriedBrainrot();
    if (carried) {
      carried.x = p.x;
      carried.y = p.y;
      carried.z = p.z + 1.15;
      if (pointInBase(p, game.brainrotBase)) deliverBrainrot(carried);
    } else {
      const nearby = game.brainrots.find(item => !item.delivered && !item.carried && Math.hypot(p.x - item.x, p.y - item.y) < .85 && Math.abs(p.z - highestBlockAt(item.x, item.y)) < 1.5);
      if (nearby) pickUpBrainrot(nearby);
    }
    updateBrainrotHud();
  }
  function updateBrainrotHud() {
    const card = document.getElementById('brainrotCard');
    if (!card) return;
    if (!game.brainrotMode) { card.hidden = true; return; }
    card.hidden = false;
    const carried = carriedBrainrot();
    const storedText = `${game.brainrotScore} stored`;
    const activeLeft = game.brainrots.filter(item => !item.delivered).length;
    $('#brainrotScore').textContent = storedText;
    $('#brainrotStatus').textContent = carried
      ? `Carrying ${carried.name}. Run to YOUR BASE!`
      : game.brainrotSpawnCooldown > 0
        ? 'New brainrots are spawning...'
        : `${activeLeft} brainrot${activeLeft === 1 ? '' : 's'} out there. Touch one to grab it.`;
  }

  function update(dt) {
    if (game.paused) return;
    game.time += dt;
    Object.keys(game.boosts).forEach(key => { game.boosts[key] = Math.max(0, (game.boosts[key] || 0) - dt); });
    const p = game.player, speed = (game.keys.shift ? 4.4 : 3.2) * (game.boosts.speed > 0 ? 1.45 : 1) * dt;
    let dx = 0, dy = 0;
    if (game.brainrotMode) {
      let forwardMove = 0, sideMove = 0;
      if (game.keys.w || game.keys.arrowup) forwardMove += 1;
      if (game.keys.s || game.keys.arrowdown) forwardMove -= 1;
      if (game.keys.a || game.keys.arrowleft) sideMove -= 1;
      if (game.keys.d || game.keys.arrowright) sideMove += 1;
      if (forwardMove && sideMove) { forwardMove *= Math.SQRT1_2; sideMove *= Math.SQRT1_2; }
      const forward = { x:Math.sin(game.look.yaw), y:-Math.cos(game.look.yaw) };
      const right = { x:Math.cos(game.look.yaw), y:Math.sin(game.look.yaw) };
      dx = (forward.x * forwardMove + right.x * sideMove) * speed;
      dy = (forward.y * forwardMove + right.y * sideMove) * speed;
      if (dx || dy) p.angle = Math.atan2(dy, dx);
    } else {
      if (game.keys.w || game.keys.arrowup) { dx -= speed; dy -= speed; }
      if (game.keys.s || game.keys.arrowdown) { dx += speed; dy += speed; }
      if (game.keys.a || game.keys.arrowleft) { dx -= speed; dy += speed; }
      if (game.keys.d || game.keys.arrowright) { dx += speed; dy -= speed; }
      if (dx || dy) { const scale = Math.SQRT1_2; dx *= scale; dy *= scale; p.angle = Math.atan2(dy, dx); }
    }
    const nx = Math.max(.25, Math.min(game.worldSize - .25, p.x + dx)), ny = Math.max(.25, Math.min(game.worldSize - .25, p.y + dy));
    const currentFloor = highestBlockAt(p.x, p.y), nextFloor = highestBlockAt(nx, ny);
    if (nextFloor <= currentFloor + 1 || p.z > nextFloor * .9) { p.x = nx; p.y = ny; }
    const floor = highestBlockAt(p.x, p.y);
    if ((game.keys[' '] || game.keys.space) && p.z <= floor + .01) { p.vz = game.boosts.jump > 0 ? 9.6 : 7.4; beep(360, .05, .012); }
    p.vz -= 18 * dt; p.z += p.vz * dt;
    if (p.z < floor) { p.z = floor; p.vz = 0; }
    const target = project(p.x, p.y, p.z);
    game.camera.x += (target.x - canvas.width/2) * dt * 2.2;
    game.camera.y += (target.y - canvas.height*.54) * dt * 2.2;
    if (profile.equippedPet) {
      const followX = Math.max(.25, Math.min(game.worldSize - .25, p.x - .72));
      const followY = Math.max(.25, Math.min(game.worldSize - .25, p.y + .48));
      const followSpeed = Math.min(1, dt * 5.5);
      game.pet.x += (followX - game.pet.x) * followSpeed;
      game.pet.y += (followY - game.pet.y) * followSpeed;
      game.pet.z = highestBlockAt(game.pet.x, game.pet.y);
    }
    game.coins.forEach(coin => {
      if (!coin.got && Math.hypot(p.x-coin.x,p.y-coin.y) < (game.boosts.magnet > 0 ? 1.7 : .52) && Math.abs(p.z-coin.z) < 1.2) {
        coin.got = true; game.collected++; profile.coins += 5; profile.xp = Math.min(500, profile.xp + 18); saveProfile();
        spawnParticles(coin.x,coin.y,coin.z,game.world.accent,18); showToast(game.world.name === 'CRYSTAL CAVERNS' ? 'Crystal recovered!' : 'Coin collected!', '+5 R • +18 XP'); updateQuest(); beep(920,.1,.035);
        if (game.collected === 5) setTimeout(() => { showToast('Quest complete!', '+50 R reward'); profile.coins += 50; saveProfile(); beep(1100,.2,.04); }, 500);
      }
    });
    game.particles.forEach(particle => { particle.z += particle.vz*dt; particle.x += particle.vx*dt; particle.y += particle.vy*dt; particle.vz -= 5*dt; particle.life -= dt; });
    game.particles = game.particles.filter(particle => particle.life > 0);
    if (game.npc.talk) game.npc.talk -= dt;
    updateBrainrotMode(dt);
    updateInteractPrompt();
  }

  function updateQuest() {
    if (game.brainrotMode) {
      $('#questCount').textContent = `${game.brainrotScore}`;
      $('#questProgress').style.width = `${Math.min(100, game.brainrotScore * 20)}%`;
      return;
    }
    $('#questCount').textContent = `${Math.min(5,game.collected)}/5`;
    $('#questProgress').style.width = `${Math.min(100,game.collected/5*100)}%`;
  }
  let toastTimer;
  function showToast(title, text) {
    const toast = $('#toast'); $('b',toast).textContent = title; $('small',toast).textContent = text; toast.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 1800);
  }
  function spawnParticles(x,y,z,color,count) { for(let i=0;i<count;i++) game.particles.push({x,y,z,vx:rand(-1,1),vy:rand(-1,1),vz:rand(1.5,4),life:rand(.4,.9),color}); }

  function drawDiamond(x,y,top,left,right,height=0) {
    const p = project(x,y,height), w=tileW/2,h=tileH/2;
    ctx.fillStyle=top;ctx.beginPath();ctx.moveTo(p.x,p.y-h);ctx.lineTo(p.x+w,p.y);ctx.lineTo(p.x,p.y+h);ctx.lineTo(p.x-w,p.y);ctx.closePath();ctx.fill();
    if(height>0){const bottom=project(x,y,0);ctx.fillStyle=left;ctx.beginPath();ctx.moveTo(p.x-w,p.y);ctx.lineTo(p.x,p.y+h);ctx.lineTo(bottom.x,bottom.y+h);ctx.lineTo(bottom.x-w,bottom.y);ctx.closePath();ctx.fill();ctx.fillStyle=right;ctx.beginPath();ctx.moveTo(p.x+w,p.y);ctx.lineTo(p.x,p.y+h);ctx.lineTo(bottom.x,bottom.y+h);ctx.lineTo(bottom.x+w,bottom.y);ctx.closePath();ctx.fill();}
  }

  function drawBrainrotBaseZone(zone) {
    if (!zone) return;
    ctx.save();
    ctx.globalAlpha = .32;
    for (let x = zone.x; x < zone.x + zone.w; x++) {
      for (let y = zone.y; y < zone.y + zone.h; y++) drawDiamond(x + .5, y + .5, zone.color, shade(zone.color, -45), shade(zone.color, -65), .03);
    }
    ctx.globalAlpha = 1;
    const p = project(zone.x + zone.w / 2, zone.y + zone.h / 2, .28);
    ctx.fillStyle = '#07111bcc';
    ctx.fillRect(p.x - 56, p.y - 34, 112, 18);
    ctx.strokeStyle = zone.color;
    ctx.strokeRect(p.x - 56, p.y - 34, 112, 18);
    ctx.fillStyle = '#f8fbff';
    ctx.font = '900 8px Chakra Petch';
    ctx.textAlign = 'center';
    ctx.fillText(zone.label, p.x, p.y - 22);
    ctx.restore();
  }
  function drawBrainrotBaseZones() {
    if (!game.brainrotMode) return;
    drawBrainrotBaseZone(game.brainrotEnemyBase);
    drawBrainrotBaseZone(game.brainrotBase);
  }

  function drawBrainrot(brainrot) {
    const float = Math.sin(game.time * 4 + brainrot.phase) * .12;
    const p = project(brainrot.x, brainrot.y, (brainrot.z || highestBlockAt(brainrot.x, brainrot.y)) + float + .42);
    ctx.save();
    ctx.translate(p.x, p.y - 28);
    ctx.shadowColor = brainrot.accent || game.world.accent;
    ctx.shadowBlur = 18;
    ctx.fillStyle = brainrot.color || '#ffcf5a';
    ctx.beginPath();
    ctx.ellipse(0, 0, 19, 17, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#101728';
    ctx.fillRect(-12, -7, 24, 14);
    ctx.fillStyle = '#f8fbff';
    ctx.font = '900 9px Chakra Petch';
    ctx.textAlign = 'center';
    ctx.fillText(brainrot.tag || 'BR', 0, 3);
    const label = String(brainrot.name || 'Brainrot').toUpperCase().slice(0, 14);
    const labelWidth = Math.max(62, ctx.measureText(label).width + 14);
    ctx.fillStyle = '#101728dd';
    ctx.fillRect(-labelWidth / 2, -39, labelWidth, 15);
    ctx.fillStyle = brainrot.accent || '#54edff';
    ctx.font = '800 7px Inter';
    ctx.fillText(label, 0, -29);
    ctx.restore();
  }

  function drawRobuxMachine(block) {
    drawDiamond(block.x + .5, block.y + .5, '#ffd75f', '#c28723', '#935b16', .18);
    const p = project(block.x + .5, block.y + .5, .35);
    ctx.save();
    ctx.translate(p.x, p.y - 42);
    ctx.shadowColor = '#ffd35a';
    ctx.shadowBlur = 18;
    ctx.fillStyle = '#1a2238';
    ctx.fillRect(-18, -8, 36, 47);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#31405f';
    ctx.fillRect(-14, -4, 28, 20);
    ctx.fillStyle = '#ffe57b';
    ctx.beginPath();
    ctx.arc(0, 6, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#6c4300';
    ctx.font = '900 11px Chakra Petch';
    ctx.textAlign = 'center';
    ctx.fillText('R', 0, 10);
    ctx.fillStyle = '#7557ff';
    ctx.fillRect(-14, 20, 28, 8);
    ctx.fillStyle = '#f8fbff';
    ctx.font = '800 6px Chakra Petch';
    ctx.fillText('SHOP', 0, 27);
    ctx.restore();
  }

  function drawBlock(block) {
    if (block.type === 4) { drawRobuxMachine(block); return; }
    const colors = block.type===3 ? ['#68ebff','#2a9bad','#1a748a'] : block.type===2 ? ['#99a3af','#69737e','#505966'] : [game.world.ground,shade(game.world.ground,-30),shade(game.world.ground,-45)];
    const p=project(block.x+.5,block.y+.5,block.h), w=tileW/2,h=tileH/2,b=project(block.x+.5,block.y+.5,0);
    ctx.fillStyle=colors[0];ctx.beginPath();ctx.moveTo(p.x,p.y-h);ctx.lineTo(p.x+w,p.y);ctx.lineTo(p.x,p.y+h);ctx.lineTo(p.x-w,p.y);ctx.closePath();ctx.fill();
    ctx.fillStyle=colors[1];ctx.beginPath();ctx.moveTo(p.x-w,p.y);ctx.lineTo(p.x,p.y+h);ctx.lineTo(b.x,b.y+h);ctx.lineTo(b.x-w,b.y);ctx.closePath();ctx.fill();
    ctx.fillStyle=colors[2];ctx.beginPath();ctx.moveTo(p.x+w,p.y);ctx.lineTo(p.x,p.y+h);ctx.lineTo(b.x,b.y+h);ctx.lineTo(b.x+w,b.y);ctx.closePath();ctx.fill();
    if(block.type===3){ctx.save();ctx.shadowColor='#5feaff';ctx.shadowBlur=20;ctx.strokeStyle='#9ff6ff';ctx.stroke();ctx.restore();}
  }

  function drawAvatar(x,y,z,isNpc=false, avatarProfile=profile, displayName='') {
    const p=project(x,y,z), bounce=Math.sin(game.time*8)*((game.keys.w||game.keys.a||game.keys.s||game.keys.d)&&!isNpc?2:0), scale=1;
    ctx.save();ctx.translate(p.x,p.y-42+bounce);ctx.scale(scale,scale);
    ctx.fillStyle='#0004';ctx.beginPath();ctx.ellipse(0,43,22,8,0,0,Math.PI*2);ctx.fill();
    const shirt=isNpc?'#22b89a':avatarProfile.shirt, skin=isNpc?'#e9a96d':avatarProfile.skin, pants=isNpc?'#29355c':(avatarProfile.pants||'#28325e'), accent=isNpc?'#e9f4ff':(avatarProfile.accent||'#55e6ff');
    // legs
    ctx.fillStyle=pants;ctx.fillRect(-17,20,14,29);ctx.fillRect(3,20,14,29);
    // arms and body
    ctx.fillStyle=skin;ctx.fillRect(-27,-12,10,31);ctx.fillRect(17,-12,10,31);ctx.fillStyle=shirt;ctx.fillRect(-18,-17,36,40);
    if(!isNpc&&avatarProfile.outfit==='stripe'){ctx.fillStyle=accent;ctx.fillRect(-4,-17,8,40);}
    else if(!isNpc&&avatarProfile.outfit==='hoodie'){ctx.strokeStyle=accent;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,-14,12,0,Math.PI);ctx.stroke();}
    else if(!isNpc&&avatarProfile.outfit==='cyber'){ctx.strokeStyle=accent;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-12,4);ctx.lineTo(-3,4);ctx.lineTo(2,-6);ctx.lineTo(7,13);ctx.lineTo(14,13);ctx.stroke();}
    else{ctx.fillStyle='#fff';ctx.font='bold 18px Chakra Petch';ctx.textAlign='center';ctx.fillText(isNpc?'N':'R',0,10);}
    // head
    ctx.fillStyle=skin;ctx.fillRect(-15,-47,30,27);ctx.fillStyle='#202330';ctx.fillRect(-8,-37,3,4);ctx.fillRect(6,-37,3,4);ctx.fillRect(-4,-29,9,2);
    ctx.fillStyle=isNpc?'#e9f4ff':(avatarProfile.hairColor||'#2b1b18');
    if(isNpc||avatarProfile.hair==='spikes'){ctx.beginPath();ctx.moveTo(-17,-46);ctx.lineTo(-13,-60);ctx.lineTo(-6,-50);ctx.lineTo(0,-63);ctx.lineTo(6,-50);ctx.lineTo(14,-59);ctx.lineTo(17,-45);ctx.closePath();ctx.fill();}
    else if(avatarProfile.hair==='cap'){ctx.beginPath();ctx.ellipse(0,-49,18,10,0,Math.PI,0);ctx.fill();ctx.fillRect(8,-50,16,4);}
    if(isNpc){ctx.fillStyle='#111827cc';ctx.fillRect(-25,-80,50,15);ctx.fillStyle='#fff';ctx.font='bold 8px Inter';ctx.fillText('NOVA',0,-70);}
    else if(displayName){const safeName=String(displayName).slice(0,16).toUpperCase();ctx.font='bold 8px Inter';const width=Math.max(52,ctx.measureText(safeName).width+14);ctx.fillStyle='#111827dd';ctx.fillRect(-width/2,-80,width,16);ctx.fillStyle='#55e6ff';ctx.textAlign='center';ctx.fillText(safeName,0,-69);}
    ctx.restore();
  }

  function drawPet() {
    const pet = [...petCatalog, ...(profile.customPets || [])].find(item => item.id === profile.equippedPet);
    if (!pet) return;
    const p = project(game.pet.x, game.pet.y, game.pet.z), bob = Math.sin(game.time * 5) * 2;
    ctx.save(); ctx.translate(p.x, p.y - 22 + bob);
    ctx.fillStyle = '#0005'; ctx.beginPath(); ctx.ellipse(0, 23, 18, 6, 0, 0, Math.PI * 2); ctx.fill();
    if (pet.type === 'dragon') { ctx.fillStyle = pet.accent; ctx.beginPath(); ctx.moveTo(-14,-7);ctx.lineTo(-27,-18);ctx.lineTo(-22,3);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(14,-7);ctx.lineTo(27,-18);ctx.lineTo(22,3);ctx.closePath();ctx.fill(); }
    if (pet.type === 'cat' || pet.type === 'dragon') { ctx.fillStyle = pet.color; ctx.beginPath();ctx.moveTo(-13,-17);ctx.lineTo(-9,-30);ctx.lineTo(-2,-18);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(13,-17);ctx.lineTo(9,-30);ctx.lineTo(2,-18);ctx.closePath();ctx.fill(); }
    if (pet.type === 'pup') { ctx.fillStyle = pet.accent; ctx.fillRect(-18,-20,7,15);ctx.fillRect(11,-20,7,15); }
    ctx.fillStyle = pet.color; ctx.fillRect(-15,-19,30,27); ctx.fillRect(-11,8,8,12); ctx.fillRect(3,8,8,12);
    if (pet.type === 'bot') { ctx.strokeStyle = pet.accent;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(0,-19);ctx.lineTo(0,-29);ctx.stroke();ctx.fillStyle=pet.accent;ctx.fillRect(-3,-33,6,6); }
    ctx.fillStyle = '#182035'; ctx.fillRect(-8,-9,4,5);ctx.fillRect(4,-9,4,5);
    ctx.fillStyle = pet.accent; ctx.fillRect(-10,1,20,3);
    ctx.fillStyle = '#101728dd';ctx.fillRect(-25,-48,50,13);ctx.fillStyle='#fff';ctx.font='bold 7px Inter';ctx.textAlign='center';ctx.fillText(pet.name.toUpperCase(),0,-39);
    ctx.restore();
  }

  function drawCoin(coin) {
    const p=project(coin.x,coin.y,coin.z+Math.sin(game.time*2.8+coin.phase)*.16), squash=Math.abs(Math.cos(game.time*2.4+coin.phase));
    ctx.save();ctx.translate(p.x,p.y-19);ctx.shadowColor=game.world.accent;ctx.shadowBlur=18;ctx.fillStyle=game.world.accent;ctx.beginPath();ctx.ellipse(0,0,10*squash+2,14,0,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#4d3b12';ctx.font='bold 9px Chakra Petch';ctx.textAlign='center';ctx.fillText(game.world===worlds.caverns?'◆':'R',0,3);ctx.restore();
  }

  function drawDecor() {
    const edge = game.worldSize - 1;
    [[1.1,1.3],[edge-.5,1.1],[.7,edge-1.3],[edge,edge-.2]].forEach(([x,y],i)=>{
      const p=project(x,y,0);ctx.fillStyle=i%2?'#754a2d':'#5a3a27';ctx.fillRect(p.x-3,p.y-32,6,32);ctx.fillStyle=shade(game.world.ground,i%2?15:25);ctx.beginPath();ctx.arc(p.x,p.y-42,17,0,Math.PI*2);ctx.arc(p.x-11,p.y-33,13,0,Math.PI*2);ctx.arc(p.x+11,p.y-33,13,0,Math.PI*2);ctx.fill();
    });
  }

  function brainrotCameraBasis() {
    const forward = { x:Math.sin(game.look.yaw), y:-Math.cos(game.look.yaw) };
    const right = { x:Math.cos(game.look.yaw), y:Math.sin(game.look.yaw) };
    return {
      forward,
      right,
      x:game.player.x - forward.x * 1.18,
      y:game.player.y - forward.y * 1.18
    };
  }
  function projectBrainrot3D(x, y, z = 0) {
    const camera = brainrotCameraBasis();
    const dx = x - camera.x;
    const dy = y - camera.y;
    const depth = dx * camera.forward.x + dy * camera.forward.y;
    if (depth <= .18) return null;
    const scale = Math.min(1.25, 1 / depth);
    const side = dx * camera.right.x + dy * camera.right.y;
    const horizon = canvas.height * (.17 - game.look.pitch * .16);
    const floorLine = canvas.height * (.91 - game.look.pitch * .1);
    const laneWidth = Math.min(220, Math.max(115, canvas.width * .24));
    return {
      x: canvas.width / 2 + side * laneWidth * scale,
      y: horizon + (floorLine - horizon) * scale - z * 76 * scale,
      scale,
      depth
    };
  }
  function fillShape(points, color, stroke = '#00000024') {
    if (points.some(point => !point)) return;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    points.slice(1).forEach(point => ctx.lineTo(point.x, point.y));
    ctx.closePath();
    ctx.fill();
    if (stroke) { ctx.strokeStyle = stroke; ctx.stroke(); }
  }
  function brainrotTileColor(x, y) {
    const point = { x:x + .5, y:y + .5 };
    if (pointInBase(point, game.brainrotBase)) return (x + y) % 2 ? '#fff42d' : '#ffe432';
    if (pointInBase(point, game.brainrotEnemyBase)) return (x + y) % 2 ? '#ff514d' : '#ff7a3d';
    const center = (game.worldSize - 1) / 2;
    const laneWidth = Math.max(1.7, Math.min(3.2, game.worldSize / 10));
    if (Math.abs(point.x - center) <= laneWidth) return (x + y) % 2 ? '#ffb347' : '#ffdb3f';
    return (x + y) % 2 ? shade(game.world.ground, 8) : shade(game.world.ground, -5);
  }
  function draw3DPlatformTile(x, y, color, z = 0, thickness = .2) {
    const a = projectBrainrot3D(x, y + 1, z), b = projectBrainrot3D(x + 1, y + 1, z), c = projectBrainrot3D(x + 1, y, z), d = projectBrainrot3D(x, y, z);
    if (!a || !b || !c || !d) return;
    const ab = projectBrainrot3D(x, y + 1, z - thickness), bb = projectBrainrot3D(x + 1, y + 1, z - thickness);
    const cb = projectBrainrot3D(x + 1, y, z - thickness), db = projectBrainrot3D(x, y, z - thickness);
    fillShape([a, b, bb, ab], shade(color, -48), null);
    fillShape([b, c, cb, bb], shade(color, -35), null);
    fillShape([a, d, db, ab], shade(color, -60), null);
    fillShape([a, b, c, d], color, '#ffffff22');
  }
  function draw3DText(text, x, y, z, color = '#ffffff') {
    const p = projectBrainrot3D(x, y, z);
    if (!p || p.scale < .045) return;
    const label = String(text).slice(0, 18).toUpperCase();
    const size = Math.max(8, Math.min(18, 16 * p.scale));
    ctx.save();
    ctx.font = `900 ${size}px Chakra Petch`;
    ctx.textAlign = 'center';
    const width = ctx.measureText(label).width + 16;
    ctx.fillStyle = '#08111cdd';
    ctx.fillRect(p.x - width / 2, p.y - size - 12, width, size + 10);
    ctx.strokeStyle = color;
    ctx.strokeRect(p.x - width / 2, p.y - size - 12, width, size + 10);
    ctx.fillStyle = color;
    ctx.fillText(label, p.x, p.y - 10);
    ctx.restore();
  }
  function block3DColor(block) {
    if (block.type === 4) return '#ffd75f';
    if (block.type === 3) return '#68ebff';
    if (block.type === 2) return '#a8b2c0';
    return game.world.ground;
  }
  function draw3DRobuxMachine(block) {
    const p = projectBrainrot3D(block.x + .5, block.y + .5, .86);
    if (!p) return;
    const s = Math.max(.12, Math.min(1, p.scale));
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.scale(s, s);
    ctx.shadowColor = '#ffd35a';
    ctx.shadowBlur = 18;
    ctx.fillStyle = '#172033';
    ctx.fillRect(-25, -55, 50, 64);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#31405f';
    ctx.fillRect(-18, -48, 36, 25);
    ctx.fillStyle = '#ffe57b';
    ctx.beginPath();
    ctx.arc(0, -34, 11, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#6c4300';
    ctx.font = '900 13px Chakra Petch';
    ctx.textAlign = 'center';
    ctx.fillText('R', 0, -29);
    ctx.fillStyle = '#7557ff';
    ctx.fillRect(-18, -14, 36, 13);
    ctx.fillStyle = '#f8fbff';
    ctx.font = '900 8px Chakra Petch';
    ctx.fillText('SHOP', 0, -4);
    ctx.restore();
  }
  function draw3DBlock(block) {
    const color = block3DColor(block);
    draw3DPlatformTile(block.x, block.y, color, Math.max(.18, block.h * .38), Math.max(.28, block.h * .38));
    if (block.type === 4) draw3DRobuxMachine(block);
  }
  function draw3DBrainrot(brainrot) {
    const carried = brainrot.carried && game.carriedBrainrot === brainrot.id;
    const p = carried ? { x:canvas.width / 2 + 42, y:canvas.height * .61, scale:.92 } : projectBrainrot3D(brainrot.x, brainrot.y, .75 + Math.sin(game.time * 4 + brainrot.phase) * .1);
    if (!p || p.scale < .045) return;
    const s = Math.max(.18, Math.min(.95, p.scale * 1.15));
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.scale(s, s);
    ctx.shadowColor = brainrot.accent || game.world.accent;
    ctx.shadowBlur = 18;
    ctx.fillStyle = brainrot.color || '#ffcf5a';
    ctx.beginPath();
    ctx.ellipse(0, 0, 28, 24, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#101728';
    ctx.fillRect(-17, -10, 34, 19);
    ctx.fillStyle = '#f8fbff';
    ctx.font = '900 12px Chakra Petch';
    ctx.textAlign = 'center';
    ctx.fillText(brainrot.tag || 'BR', 0, 4);
    if (p.scale > .11 || carried) {
      const label = String(brainrot.name || 'Brainrot').toUpperCase().slice(0, 16);
      const width = Math.max(72, ctx.measureText(label).width + 14);
      ctx.fillStyle = '#101728dd';
      ctx.fillRect(-width / 2, -50, width, 18);
      ctx.fillStyle = brainrot.accent || '#54edff';
      ctx.font = '900 8px Inter';
      ctx.fillText(label, 0, -37);
    }
    ctx.restore();
  }
  function drawAvatar3DAt(x, y, scale = 1, avatarProfile = profile, displayName = '', isNpc = false) {
    const s = Math.max(.22, Math.min(1.15, scale));
    const moving = game.keys.w || game.keys.a || game.keys.s || game.keys.d;
    const bob = moving && !isNpc ? Math.sin(game.time * 9) * 3 : 0;
    const shirt = isNpc ? '#22b89a' : avatarProfile.shirt;
    const skin = isNpc ? '#e9a96d' : avatarProfile.skin;
    const pants = isNpc ? '#29355c' : (avatarProfile.pants || '#28325e');
    const accent = isNpc ? '#e9f4ff' : (avatarProfile.accent || '#55e6ff');
    ctx.save();
    ctx.translate(x, y + bob);
    ctx.scale(s, s);
    ctx.fillStyle = '#0005';
    ctx.beginPath();
    ctx.ellipse(0, 6, 28, 9, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = pants;
    ctx.fillRect(-20, -42, 16, 43);
    ctx.fillRect(4, -42, 16, 43);
    ctx.fillStyle = skin;
    ctx.fillRect(-34, -90, 12, 45);
    ctx.fillRect(22, -90, 12, 45);
    ctx.fillStyle = shirt;
    ctx.fillRect(-24, -94, 48, 55);
    ctx.fillStyle = accent;
    ctx.fillRect(-5, -94, 10, 55);
    ctx.fillStyle = skin;
    ctx.fillRect(-18, -132, 36, 32);
    ctx.fillStyle = avatarProfile.hairColor || '#2b1b18';
    ctx.fillRect(-20, -136, 40, 11);
    ctx.fillRect(-15, -144, 10, 11);
    ctx.fillRect(4, -145, 10, 12);
    ctx.fillStyle = '#202330';
    ctx.fillRect(-9, -119, 4, 5);
    ctx.fillRect(6, -119, 4, 5);
    ctx.fillRect(-5, -109, 10, 3);
    if (displayName) {
      const safeName = String(displayName).slice(0, 16).toUpperCase();
      ctx.font = '900 9px Inter';
      ctx.textAlign = 'center';
      const width = Math.max(58, ctx.measureText(safeName).width + 14);
      ctx.fillStyle = '#101728dd';
      ctx.fillRect(-width / 2, -168, width, 17);
      ctx.fillStyle = isNpc ? '#e9f4ff' : '#55e6ff';
      ctx.fillText(safeName, 0, -156);
    }
    ctx.restore();
  }
  function draw3DPet() {
    const pet = [...petCatalog, ...(profile.customPets || [])].find(item => item.id === profile.equippedPet);
    if (!pet) return;
    const p = projectBrainrot3D(game.pet.x, game.pet.y, game.pet.z + .25);
    if (!p) return;
    const s = Math.max(.18, Math.min(.72, p.scale * .8));
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.scale(s, s);
    ctx.fillStyle = '#0005';
    ctx.beginPath();
    ctx.ellipse(0, 12, 20, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = pet.color;
    ctx.fillRect(-18, -22, 36, 31);
    ctx.fillRect(-13, 5, 10, 17);
    ctx.fillRect(4, 5, 10, 17);
    ctx.fillStyle = '#182035';
    ctx.fillRect(-9, -10, 5, 6);
    ctx.fillRect(5, -10, 5, 6);
    ctx.fillStyle = pet.accent;
    ctx.fillRect(-12, 0, 24, 4);
    ctx.restore();
  }
  function renderBrainrot3D() {
    const w = canvas.width, h = canvas.height;
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#73d7ff');
    sky.addColorStop(.62, '#a7eaff');
    sky.addColorStop(1, '#d9f8ff');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#ffffff80';
    for (let i = 0; i < 8; i++) {
      const x = (i * 230 - game.player.x * 18) % (w + 260) - 130;
      const y = 58 + (i % 3) * 34;
      ctx.beginPath();
      ctx.ellipse(x, y, 62, 15, 0, 0, Math.PI * 2);
      ctx.ellipse(x + 48, y + 6, 46, 12, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    const size = game.worldSize;
    const reach = Math.max(28, Math.min(48, Math.ceil(h / 16)));
    const minY = Math.max(0, Math.floor(game.player.y - reach));
    const maxY = Math.min(size - 1, Math.ceil(game.player.y + reach));
    const minX = Math.max(0, Math.floor(game.player.x - reach));
    const maxX = Math.min(size - 1, Math.ceil(game.player.x + reach));
    const visibleTiles = [];
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        const p = projectBrainrot3D(x + .5, y + .5, 0);
        if (p && p.scale > .018) visibleTiles.push({ x, y, depth:p.depth });
      }
    }
    visibleTiles.sort((a, b) => b.depth - a.depth).forEach(tile => draw3DPlatformTile(tile.x, tile.y, brainrotTileColor(tile.x, tile.y), 0, .18));
    draw3DText(game.brainrotEnemyBase?.label || 'BRAINROT DEN', game.brainrotEnemyBase?.x + game.brainrotEnemyBase?.w / 2 || size / 2, game.brainrotEnemyBase?.y || 1, .35, '#ff89d9');
    draw3DText(game.brainrotBase?.label || 'YOUR BASE', game.brainrotBase?.x + game.brainrotBase?.w / 2 || size / 2, game.brainrotBase?.y || size - 4, .35, '#8df4cc');
    game.blocks
      .filter(block => block.x >= minX - 1 && block.x <= maxX + 1 && block.y >= minY - 1 && block.y <= maxY + 1)
      .map(block => ({ block, p:projectBrainrot3D(block.x + .5, block.y + .5, block.h * .38) }))
      .filter(item => item.p && item.p.scale > .025)
      .sort((a, b) => b.p.depth - a.p.depth)
      .map(item => item.block)
      .forEach(draw3DBlock);
    game.coins.filter(c => !c.got).forEach(coin => {
      const p = projectBrainrot3D(coin.x, coin.y, coin.z + .25);
      if (!p || p.scale < .05) return;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.scale(Math.max(.16, p.scale), Math.max(.16, p.scale));
      ctx.fillStyle = game.world.accent;
      ctx.shadowColor = game.world.accent;
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.arc(0, 0, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
    game.brainrots.filter(item => !item.delivered).sort((a, b) => {
      const pa = projectBrainrot3D(a.x, a.y, .75), pb = projectBrainrot3D(b.x, b.y, .75);
      return (pb?.depth || -1) - (pa?.depth || -1);
    }).forEach(draw3DBrainrot);
    multiplayer.players.forEach(player => {
      const p = projectBrainrot3D(player.x, player.y, player.z);
      if (p && p.scale > .06) drawAvatar3DAt(p.x, p.y, p.scale * .9, player, player.username);
    });
    const npc = projectBrainrot3D(game.npc.x, game.npc.y, 0);
    if (npc && npc.scale > .07) drawAvatar3DAt(npc.x, npc.y, npc.scale * .85, profile, 'NOVA', true);
    draw3DPet();
    game.particles.forEach(particle => {
      const p = projectBrainrot3D(particle.x, particle.y, particle.z);
      if (!p) return;
      ctx.globalAlpha = Math.max(0, particle.life * 1.4);
      ctx.fillStyle = particle.color;
      const s = Math.max(2, 8 * p.scale);
      ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
      ctx.globalAlpha = 1;
    });
    drawAvatar3DAt(w / 2, h * .82, Math.max(.86, Math.min(1.05, w / 900)), profile, profile.name);
    ctx.fillStyle = '#ffffffcc';
    ctx.font = '900 10px Chakra Petch';
    ctx.textAlign = 'center';
    ctx.fillText(game.look.locked ? 'MOUSE LOOK ON • ESC RELEASES' : 'CLICK GAME TO LOOK AROUND', w / 2, h * .965);
  }

  function render() {
    if (game.brainrotMode) { renderBrainrot3D(); return; }
    const w=canvas.width,h=canvas.height,gradient=ctx.createLinearGradient(0,0,0,h);gradient.addColorStop(0,game.world.sky[0]);gradient.addColorStop(1,game.world.sky[1]);ctx.fillStyle=gradient;ctx.fillRect(0,0,w,h);
    // distant silhouettes
    ctx.fillStyle='#ffffff10';for(let i=0;i<12;i++){const x=(i*173-game.camera.x*.08)%(w+180)-90, height=70+(i*47)%170;ctx.fillRect(x,h*.22-height/2,80,height);}
    const groundTop=game.world.ground,groundLeft=shade(groundTop,-35),groundRight=shade(groundTop,-50);
    const size=game.worldSize;
    const viewRadius = size > 56 ? 30 : size;
    const minX = Math.max(0, Math.floor(game.player.x - viewRadius));
    const maxX = Math.min(size - 1, Math.ceil(game.player.x + viewRadius));
    const minY = Math.max(0, Math.floor(game.player.y - viewRadius));
    const maxY = Math.min(size - 1, Math.ceil(game.player.y + viewRadius));
    for(let sum=minX+minY;sum<=maxX+maxY;sum++)for(let x=minX;x<=maxX;x++){const y=sum-x;if(y<minY||y>maxY)continue;const p=project(x+.5,y+.5,0),tw=tileW/2,th=tileH/2;ctx.fillStyle=(x+y)%2?groundTop:shade(groundTop,5);ctx.beginPath();ctx.moveTo(p.x,p.y-th);ctx.lineTo(p.x+tw,p.y);ctx.lineTo(p.x,p.y+th);ctx.lineTo(p.x-tw,p.y);ctx.closePath();ctx.fill();ctx.strokeStyle='#ffffff0b';ctx.stroke();if(x===size-1||y===size-1){ctx.fillStyle=x===size-1?groundRight:groundLeft;ctx.beginPath();ctx.moveTo(p.x+(x===size-1?tw:-tw),p.y);ctx.lineTo(p.x,p.y+th);ctx.lineTo(p.x,p.y+th+35);ctx.lineTo(p.x+(x===size-1?tw:-tw),p.y+35);ctx.closePath();ctx.fill();}}
    drawBrainrotBaseZones();
    const drawables=[];
    game.blocks.filter(block=>block.x>=minX-1&&block.x<=maxX+1&&block.y>=minY-1&&block.y<=maxY+1).forEach(block=>drawables.push({sort:block.x+block.y+.1,fn:()=>drawBlock(block)}));
    game.coins.filter(c=>!c.got).forEach(c=>drawables.push({sort:c.x+c.y,fn:()=>drawCoin(c)}));
    if (game.brainrotMode) game.brainrots.filter(item=>!item.delivered).forEach(item=>drawables.push({sort:item.x+item.y+.08,fn:()=>drawBrainrot(item)}));
    drawables.push({sort:game.npc.x+game.npc.y,fn:()=>drawAvatar(game.npc.x,game.npc.y,0,true)});
    multiplayer.players.forEach(player=>drawables.push({sort:player.x+player.y,fn:()=>drawAvatar(player.x,player.y,player.z,false,player,player.username)}));
    if(profile.equippedPet)drawables.push({sort:game.pet.x+game.pet.y+.05,fn:drawPet});
    drawables.push({sort:game.player.x+game.player.y,fn:()=>drawAvatar(game.player.x,game.player.y,game.player.z,false,profile,profile.name)});
    drawables.sort((a,b)=>a.sort-b.sort).forEach(d=>d.fn());
    drawDecor();
    game.particles.forEach(particle=>{const p=project(particle.x,particle.y,particle.z);ctx.globalAlpha=Math.max(0,particle.life*1.5);ctx.fillStyle=particle.color;ctx.fillRect(p.x-3,p.y-3,6,6);ctx.globalAlpha=1;});
  }

  function loop(now) {
    if (!game.active) return;
    const dt=Math.min(.034,(now-game.last)/1000||0);game.last=now;update(dt);render();requestAnimationFrame(loop);
  }
})();
